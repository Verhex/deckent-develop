{
  "workerId": "docker-196-004",
  "taskId": "196-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:01:32.968Z",
  "exitCode": 0,
  "backend": "docker"
}