{
  "workerId": "docker-196-007",
  "taskId": "196-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T15:58:19.525Z",
  "exitCode": 0,
  "backend": "docker"
}