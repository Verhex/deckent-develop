{
  "workerId": "docker-196-003-fix",
  "taskId": "196-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:22:10.487Z",
  "exitCode": 0,
  "backend": "docker"
}