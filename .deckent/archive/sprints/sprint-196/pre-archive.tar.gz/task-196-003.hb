{
  "workerId": "docker-196-003",
  "taskId": "196-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:16:23.878Z",
  "exitCode": 0,
  "backend": "docker"
}