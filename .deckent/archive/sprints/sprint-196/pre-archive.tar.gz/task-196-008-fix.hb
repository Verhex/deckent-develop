{
  "workerId": "docker-196-008-fix",
  "taskId": "196-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:23:01.297Z",
  "exitCode": 0,
  "backend": "docker"
}