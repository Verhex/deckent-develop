{
  "workerId": "docker-196-002",
  "taskId": "196-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:04:30.128Z",
  "exitCode": 0,
  "backend": "docker"
}