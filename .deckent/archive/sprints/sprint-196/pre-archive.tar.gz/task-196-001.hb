{
  "workerId": "docker-196-001",
  "taskId": "196-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T15:50:30.743Z",
  "exitCode": 0,
  "backend": "docker"
}