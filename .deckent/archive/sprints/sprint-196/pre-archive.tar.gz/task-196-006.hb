{
  "workerId": "docker-196-006",
  "taskId": "196-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:20:06.701Z",
  "exitCode": 0,
  "backend": "docker"
}