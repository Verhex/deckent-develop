{
  "workerId": "docker-196-005",
  "taskId": "196-005",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-26T15:52:32.854Z",
  "exitCode": 137,
  "backend": "docker"
}