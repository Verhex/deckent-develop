{
  "workerId": "docker-196-001-fix",
  "taskId": "196-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:26:37.408Z",
  "exitCode": 0,
  "backend": "docker"
}