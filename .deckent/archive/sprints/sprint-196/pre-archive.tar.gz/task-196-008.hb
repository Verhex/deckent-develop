{
  "workerId": "docker-196-008",
  "taskId": "196-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:03:04.910Z",
  "exitCode": 0,
  "backend": "docker"
}