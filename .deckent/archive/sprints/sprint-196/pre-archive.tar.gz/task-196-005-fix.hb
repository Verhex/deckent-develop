{
  "workerId": "docker-196-005-fix",
  "taskId": "196-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T16:31:04.328Z",
  "exitCode": 0,
  "backend": "docker"
}