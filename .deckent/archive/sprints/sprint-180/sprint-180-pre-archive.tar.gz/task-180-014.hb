{
  "workerId": "docker-180-014",
  "taskId": "180-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:46:44.875Z",
  "exitCode": 0,
  "backend": "docker"
}