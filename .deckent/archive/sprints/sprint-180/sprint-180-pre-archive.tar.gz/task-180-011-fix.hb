{
  "workerId": "docker-180-011-fix",
  "taskId": "180-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T17:11:22.115Z",
  "exitCode": 0,
  "backend": "docker"
}