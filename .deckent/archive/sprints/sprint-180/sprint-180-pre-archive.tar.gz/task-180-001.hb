{
  "workerId": "docker-180-001",
  "taskId": "180-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:33:47.912Z",
  "exitCode": 0,
  "backend": "docker"
}