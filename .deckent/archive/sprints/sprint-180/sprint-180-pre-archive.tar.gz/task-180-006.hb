{
  "workerId": "docker-180-006",
  "taskId": "180-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:31:23.271Z",
  "exitCode": 0,
  "backend": "docker"
}