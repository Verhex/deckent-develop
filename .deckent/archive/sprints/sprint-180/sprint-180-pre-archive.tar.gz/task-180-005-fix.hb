{
  "workerId": "docker-180-005-fix",
  "taskId": "180-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:55:44.912Z",
  "exitCode": 0,
  "backend": "docker"
}