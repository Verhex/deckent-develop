{
  "workerId": "docker-180-012-fix",
  "taskId": "180-012-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:57:19.998Z",
  "exitCode": 0,
  "backend": "docker"
}