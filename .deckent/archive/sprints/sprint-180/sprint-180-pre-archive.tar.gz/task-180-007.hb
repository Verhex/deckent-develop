{
  "workerId": "docker-180-007",
  "taskId": "180-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:29:45.086Z",
  "exitCode": 0,
  "backend": "docker"
}