{
  "workerId": "docker-180-001-fix",
  "taskId": "180-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:56:03.537Z",
  "exitCode": 0,
  "backend": "docker"
}