{
  "workerId": "docker-180-002-fix",
  "taskId": "180-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:51:27.641Z",
  "exitCode": 0,
  "backend": "docker"
}