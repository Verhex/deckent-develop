{
  "workerId": "docker-180-003",
  "taskId": "180-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:27:57.003Z",
  "exitCode": 0,
  "backend": "docker"
}