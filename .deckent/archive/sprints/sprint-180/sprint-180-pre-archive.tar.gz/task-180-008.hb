{
  "workerId": "docker-180-008",
  "taskId": "180-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:41:03.938Z",
  "exitCode": 0,
  "backend": "docker"
}