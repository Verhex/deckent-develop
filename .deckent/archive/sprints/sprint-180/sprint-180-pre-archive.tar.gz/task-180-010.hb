{
  "workerId": "docker-180-010",
  "taskId": "180-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:38:51.743Z",
  "exitCode": 0,
  "backend": "docker"
}