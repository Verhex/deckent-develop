{
  "workerId": "docker-180-012",
  "taskId": "180-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:40:43.353Z",
  "exitCode": 0,
  "backend": "docker"
}