{
  "workerId": "docker-180-011",
  "taskId": "180-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:50:56.712Z",
  "exitCode": 0,
  "backend": "docker"
}