{
  "workerId": "docker-180-002",
  "taskId": "180-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:26:31.638Z",
  "exitCode": 0,
  "backend": "docker"
}