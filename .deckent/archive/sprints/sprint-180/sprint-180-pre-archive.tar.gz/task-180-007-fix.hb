{
  "workerId": "docker-180-007-fix",
  "taskId": "180-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:53:53.202Z",
  "exitCode": 0,
  "backend": "docker"
}