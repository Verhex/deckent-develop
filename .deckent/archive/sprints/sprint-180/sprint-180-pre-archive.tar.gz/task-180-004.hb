{
  "workerId": "docker-180-004",
  "taskId": "180-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:29:08.825Z",
  "exitCode": 0,
  "backend": "docker"
}