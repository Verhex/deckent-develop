{
  "workerId": "docker-180-013",
  "taskId": "180-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:46:10.525Z",
  "exitCode": 0,
  "backend": "docker"
}