{
  "workerId": "docker-180-009",
  "taskId": "180-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:39:43.541Z",
  "exitCode": 0,
  "backend": "docker"
}