{
  "workerId": "docker-180-005",
  "taskId": "180-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T16:50:56.944Z",
  "exitCode": 0,
  "backend": "docker"
}