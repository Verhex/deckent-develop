{
  "taskId": "176-002-fix",
  "workerId": "w-176-002-fix",
  "status": "EXECUTING",
  "sequence": 1,
  "timestamp": "2026-05-20T09:22:49.000Z",
  "phase": "INVESTIGATING"
}
