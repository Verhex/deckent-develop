{
  "workerId": "w-176-007-fix",
  "taskId": "176-007-fix",
  "status": "EXECUTING",
  "sequence": 2,
  "timestamp": "2026-05-20T09:24:30Z",
  "phase": "VERIFY"
}
