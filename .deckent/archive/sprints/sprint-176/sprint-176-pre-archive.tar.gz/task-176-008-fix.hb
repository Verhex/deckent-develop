{
  "taskId": "176-008-fix",
  "workerId": "w-176-008-fix",
  "status": "TESTING",
  "sequence": 2,
  "timestamp": "2026-05-20T10:05:00.000Z",
  "phase": "verifying"
}
