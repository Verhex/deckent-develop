{
  "taskId": "176-011-fix",
  "workerId": "w-176-011-fix",
  "status": "EXECUTING",
  "sequence": 1,
  "timestamp": "2026-05-20T00:00:00.000Z",
  "note": "Starting analysis"
}
