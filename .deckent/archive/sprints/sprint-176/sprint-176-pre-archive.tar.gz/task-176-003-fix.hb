{
  "workerId": "w-176-003-fix",
  "taskId": "176-003-fix",
  "status": "EXECUTING",
  "sequence": 1,
  "timestamp": "2026-05-20T00:00:00.000Z",
  "phase": "READ_PLAN"
}
