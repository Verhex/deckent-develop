{
  "taskId": "176-001-fix",
  "workerId": "w-176-001-fix",
  "status": "DONE",
  "timestamp": "2026-05-20T09:30:00.000Z",
  "sequence": 1,
  "phase": "RESULT_WRITTEN",
  "verdict": "NO_GO",
  "note": "Forensik NO_GO yazıldı; Brain'in 176-002-fix (W1-1) DONE'u beklemesi ve bu task'ı yeniden dispatch etmemesi öneriliyor"
}
