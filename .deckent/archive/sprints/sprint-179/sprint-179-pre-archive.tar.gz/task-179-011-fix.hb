{
  "workerId": "docker-179-011-fix",
  "taskId": "179-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:38:39.102Z",
  "exitCode": 0,
  "backend": "docker"
}