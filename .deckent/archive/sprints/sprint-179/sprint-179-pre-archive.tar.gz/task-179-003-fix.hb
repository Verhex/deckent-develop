{
  "workerId": "docker-179-003-fix",
  "taskId": "179-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:26:13.142Z",
  "exitCode": 0,
  "backend": "docker"
}