{
  "workerId": "docker-179-005-fix",
  "taskId": "179-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:33:47.925Z",
  "exitCode": 0,
  "backend": "docker"
}