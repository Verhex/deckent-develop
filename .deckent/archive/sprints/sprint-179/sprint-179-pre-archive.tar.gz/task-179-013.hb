{
  "workerId": "docker-179-013",
  "taskId": "179-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:20:13.591Z",
  "exitCode": 0,
  "backend": "docker"
}