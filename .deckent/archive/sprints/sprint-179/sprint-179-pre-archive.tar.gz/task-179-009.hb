{
  "workerId": "docker-179-009",
  "taskId": "179-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:00:51.720Z",
  "exitCode": 0,
  "backend": "docker"
}