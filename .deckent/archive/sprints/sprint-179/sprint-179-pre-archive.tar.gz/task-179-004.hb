{
  "workerId": "docker-179-004",
  "taskId": "179-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T12:45:32.182Z",
  "exitCode": 0,
  "backend": "docker"
}