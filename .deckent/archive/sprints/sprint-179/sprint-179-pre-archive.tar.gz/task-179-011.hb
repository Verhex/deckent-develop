{
  "workerId": "docker-179-011",
  "taskId": "179-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:28:26.518Z",
  "exitCode": 0,
  "backend": "docker"
}