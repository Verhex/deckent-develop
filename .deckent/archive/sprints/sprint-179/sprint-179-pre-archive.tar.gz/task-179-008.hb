{
  "workerId": "docker-179-008",
  "taskId": "179-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:02:32.859Z",
  "exitCode": 0,
  "backend": "docker"
}