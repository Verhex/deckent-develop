{
  "workerId": "docker-179-005",
  "taskId": "179-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:17:50.310Z",
  "exitCode": 0,
  "backend": "docker"
}