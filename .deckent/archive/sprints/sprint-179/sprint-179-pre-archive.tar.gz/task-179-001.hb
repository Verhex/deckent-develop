{
  "workerId": "docker-179-001",
  "taskId": "179-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T12:52:10.376Z",
  "exitCode": 0,
  "backend": "docker"
}