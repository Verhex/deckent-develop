{
  "workerId": "docker-179-003",
  "taskId": "179-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:24:47.345Z",
  "exitCode": 0,
  "backend": "docker"
}