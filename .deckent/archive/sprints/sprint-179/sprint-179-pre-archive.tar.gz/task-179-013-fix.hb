{
  "workerId": "docker-179-013-fix",
  "taskId": "179-013-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:24:34.813Z",
  "exitCode": 0,
  "backend": "docker"
}