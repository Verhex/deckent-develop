{
  "workerId": "docker-179-007",
  "taskId": "179-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T12:53:16.678Z",
  "exitCode": 0,
  "backend": "docker"
}