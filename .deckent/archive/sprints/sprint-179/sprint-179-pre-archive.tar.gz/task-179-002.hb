{
  "workerId": "docker-179-002",
  "taskId": "179-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:11:13.326Z",
  "exitCode": 0,
  "backend": "docker"
}