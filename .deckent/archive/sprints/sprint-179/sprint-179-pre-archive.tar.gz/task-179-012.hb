{
  "workerId": "docker-179-012",
  "taskId": "179-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:05:01.020Z",
  "exitCode": 0,
  "backend": "docker"
}