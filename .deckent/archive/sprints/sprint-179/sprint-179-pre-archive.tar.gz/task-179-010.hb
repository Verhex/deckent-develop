{
  "workerId": "docker-179-010",
  "taskId": "179-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T13:03:52.317Z",
  "exitCode": 0,
  "backend": "docker"
}