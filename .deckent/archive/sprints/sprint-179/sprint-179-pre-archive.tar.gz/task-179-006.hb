{
  "workerId": "docker-179-006",
  "taskId": "179-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T12:50:23.792Z",
  "exitCode": 0,
  "backend": "docker"
}