{
  "workerId": "docker-206-006",
  "taskId": "206-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:05:00.566Z",
  "exitCode": 0,
  "backend": "docker"
}