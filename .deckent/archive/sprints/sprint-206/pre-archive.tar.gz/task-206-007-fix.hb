{
  "workerId": "docker-206-007-fix",
  "taskId": "206-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:09:11.440Z",
  "exitCode": 0,
  "backend": "docker"
}