{
  "workerId": "docker-206-004-fix",
  "taskId": "206-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:11:21.190Z",
  "exitCode": 0,
  "backend": "docker"
}