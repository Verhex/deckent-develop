{
  "workerId": "docker-206-002",
  "taskId": "206-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:07:45.822Z",
  "exitCode": 0,
  "backend": "docker"
}