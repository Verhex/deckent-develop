{
  "workerId": "docker-206-009",
  "taskId": "206-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:03:37.774Z",
  "exitCode": 0,
  "backend": "docker"
}