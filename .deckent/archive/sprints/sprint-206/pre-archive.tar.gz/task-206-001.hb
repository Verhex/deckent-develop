{
  "workerId": "docker-206-001",
  "taskId": "206-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:01:31.132Z",
  "exitCode": 0,
  "backend": "docker"
}