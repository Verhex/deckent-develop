{
  "workerId": "docker-206-003-fix",
  "taskId": "206-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:10:38.969Z",
  "exitCode": 0,
  "backend": "docker"
}