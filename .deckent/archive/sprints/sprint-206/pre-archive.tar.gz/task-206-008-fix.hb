{
  "workerId": "docker-206-008-fix",
  "taskId": "206-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:10:22.500Z",
  "exitCode": 0,
  "backend": "docker"
}