{
  "workerId": "docker-206-004",
  "taskId": "206-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:04:49.011Z",
  "exitCode": 0,
  "backend": "docker"
}