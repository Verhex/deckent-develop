{
  "workerId": "docker-206-005-fix",
  "taskId": "206-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:09:18.282Z",
  "exitCode": 0,
  "backend": "docker"
}