{
  "workerId": "docker-206-002-fix",
  "taskId": "206-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:13:05.462Z",
  "exitCode": 0,
  "backend": "docker"
}