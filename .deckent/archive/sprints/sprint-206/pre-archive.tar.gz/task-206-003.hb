{
  "workerId": "docker-206-003",
  "taskId": "206-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:01:05.151Z",
  "exitCode": 0,
  "backend": "docker"
}