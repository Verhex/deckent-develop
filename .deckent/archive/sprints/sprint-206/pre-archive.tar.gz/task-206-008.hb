{
  "workerId": "docker-206-008",
  "taskId": "206-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:03:32.428Z",
  "exitCode": 0,
  "backend": "docker"
}