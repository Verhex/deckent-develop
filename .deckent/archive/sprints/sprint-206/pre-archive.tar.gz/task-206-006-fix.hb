{
  "workerId": "docker-206-006-fix",
  "taskId": "206-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:10:03.262Z",
  "exitCode": 0,
  "backend": "docker"
}