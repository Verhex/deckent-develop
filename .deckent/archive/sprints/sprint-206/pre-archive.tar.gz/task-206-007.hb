{
  "workerId": "docker-206-007",
  "taskId": "206-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:04:13.493Z",
  "exitCode": 0,
  "backend": "docker"
}