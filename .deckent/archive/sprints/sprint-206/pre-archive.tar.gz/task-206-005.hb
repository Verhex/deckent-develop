{
  "workerId": "docker-206-005",
  "taskId": "206-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T17:00:47.521Z",
  "exitCode": 0,
  "backend": "docker"
}