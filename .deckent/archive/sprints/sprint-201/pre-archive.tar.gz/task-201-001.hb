{
  "workerId": "docker-201-001",
  "taskId": "201-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:07:50.136Z",
  "exitCode": 0,
  "backend": "docker"
}