{
  "workerId": "docker-201-006",
  "taskId": "201-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:30:05.183Z",
  "exitCode": 0,
  "backend": "docker"
}