{
  "workerId": "docker-201-006-fix",
  "taskId": "201-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:39:35.054Z",
  "exitCode": 0,
  "backend": "docker"
}