{
  "workerId": "docker-201-005",
  "taskId": "201-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:08:24.262Z",
  "exitCode": 0,
  "backend": "docker"
}