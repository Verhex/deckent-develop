{
  "workerId": "docker-201-004",
  "taskId": "201-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:08:05.721Z",
  "exitCode": 0,
  "backend": "docker"
}