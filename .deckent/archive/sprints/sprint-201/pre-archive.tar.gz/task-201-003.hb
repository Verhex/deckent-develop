{
  "workerId": "docker-201-003",
  "taskId": "201-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:21:28.820Z",
  "exitCode": 0,
  "backend": "docker"
}