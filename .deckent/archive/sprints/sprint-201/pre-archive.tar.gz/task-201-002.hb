{
  "workerId": "docker-201-002",
  "taskId": "201-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T11:11:45.066Z",
  "exitCode": 0,
  "backend": "docker"
}