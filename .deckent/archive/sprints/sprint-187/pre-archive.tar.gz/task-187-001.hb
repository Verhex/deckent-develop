{
  "workerId": "docker-187-001",
  "taskId": "187-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T13:11:11.528Z",
  "exitCode": 0,
  "backend": "docker"
}