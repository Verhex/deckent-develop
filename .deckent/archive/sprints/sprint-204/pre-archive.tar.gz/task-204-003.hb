{
  "workerId": "docker-204-003",
  "taskId": "204-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:00:00.105Z",
  "exitCode": 0,
  "backend": "docker"
}