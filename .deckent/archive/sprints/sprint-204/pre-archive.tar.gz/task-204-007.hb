{
  "workerId": "docker-204-007",
  "taskId": "204-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:08:09.540Z",
  "exitCode": 0,
  "backend": "docker"
}