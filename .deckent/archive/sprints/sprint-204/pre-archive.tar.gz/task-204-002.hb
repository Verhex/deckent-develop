{
  "workerId": "docker-204-002",
  "taskId": "204-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:08:35.655Z",
  "exitCode": 0,
  "backend": "docker"
}