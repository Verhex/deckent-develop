{
  "workerId": "docker-204-001-fix",
  "taskId": "204-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:15:41.401Z",
  "exitCode": 0,
  "backend": "docker"
}