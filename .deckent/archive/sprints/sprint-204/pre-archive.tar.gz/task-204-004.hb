{
  "workerId": "docker-204-004",
  "taskId": "204-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:59:18.928Z",
  "exitCode": 0,
  "backend": "docker"
}