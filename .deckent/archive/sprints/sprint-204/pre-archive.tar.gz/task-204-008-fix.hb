{
  "workerId": "docker-204-008-fix",
  "taskId": "204-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:11:25.940Z",
  "exitCode": 0,
  "backend": "docker"
}