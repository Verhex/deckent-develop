{
  "workerId": "docker-204-006",
  "taskId": "204-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:08:44.929Z",
  "exitCode": 0,
  "backend": "docker"
}