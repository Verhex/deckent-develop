{
  "workerId": "docker-204-005",
  "taskId": "204-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:05:41.630Z",
  "exitCode": 0,
  "backend": "docker"
}