{
  "workerId": "docker-204-007-fix",
  "taskId": "204-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:10:06.144Z",
  "exitCode": 0,
  "backend": "docker"
}