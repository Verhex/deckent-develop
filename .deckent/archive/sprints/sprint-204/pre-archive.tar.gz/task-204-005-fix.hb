{
  "workerId": "docker-204-005-fix",
  "taskId": "204-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:10:59.986Z",
  "exitCode": 0,
  "backend": "docker"
}