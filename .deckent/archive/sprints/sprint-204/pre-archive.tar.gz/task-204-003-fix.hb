{
  "workerId": "docker-204-003-fix",
  "taskId": "204-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:11:00.351Z",
  "exitCode": 0,
  "backend": "docker"
}