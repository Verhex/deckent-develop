{
  "workerId": "docker-204-009",
  "taskId": "204-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:00:04.031Z",
  "exitCode": 0,
  "backend": "docker"
}