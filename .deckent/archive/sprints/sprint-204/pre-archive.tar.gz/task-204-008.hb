{
  "workerId": "docker-204-008",
  "taskId": "204-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:58:20.756Z",
  "exitCode": 0,
  "backend": "docker"
}