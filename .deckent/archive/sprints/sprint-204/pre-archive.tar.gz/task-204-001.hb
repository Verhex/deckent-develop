{
  "workerId": "docker-204-001",
  "taskId": "204-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:03:04.115Z",
  "exitCode": 0,
  "backend": "docker"
}