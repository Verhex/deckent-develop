{
  "workerId": "docker-204-004-fix",
  "taskId": "204-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:10:12.930Z",
  "exitCode": 0,
  "backend": "docker"
}