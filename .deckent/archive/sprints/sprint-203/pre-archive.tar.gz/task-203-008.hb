{
  "workerId": "docker-203-008",
  "taskId": "203-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:17:21.763Z",
  "exitCode": 0,
  "backend": "docker"
}