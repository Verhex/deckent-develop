{
  "workerId": "docker-203-001",
  "taskId": "203-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:18:34.493Z",
  "exitCode": 0,
  "backend": "docker"
}