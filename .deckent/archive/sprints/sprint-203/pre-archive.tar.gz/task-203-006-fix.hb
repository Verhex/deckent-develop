{
  "workerId": "docker-203-006-fix",
  "taskId": "203-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:32:43.522Z",
  "exitCode": 0,
  "backend": "docker"
}