{
  "workerId": "docker-203-007-fix",
  "taskId": "203-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:29:35.477Z",
  "exitCode": 0,
  "backend": "docker"
}