{
  "workerId": "docker-203-007",
  "taskId": "203-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:27:55.742Z",
  "exitCode": 0,
  "backend": "docker"
}