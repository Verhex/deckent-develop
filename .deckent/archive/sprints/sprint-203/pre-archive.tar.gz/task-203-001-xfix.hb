{
  "workerId": "docker-203-001-xfix",
  "taskId": "203-001-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:31:06.787Z",
  "exitCode": 0,
  "backend": "docker"
}