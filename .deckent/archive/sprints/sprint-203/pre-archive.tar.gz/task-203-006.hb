{
  "workerId": "docker-203-006",
  "taskId": "203-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:23:45.835Z",
  "exitCode": 0,
  "backend": "docker"
}