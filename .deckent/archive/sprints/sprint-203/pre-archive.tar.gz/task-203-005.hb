{
  "workerId": "docker-203-005",
  "taskId": "203-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:20:54.581Z",
  "exitCode": 0,
  "backend": "docker"
}