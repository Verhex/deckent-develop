{
  "workerId": "docker-203-004-fix",
  "taskId": "203-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:30:29.215Z",
  "exitCode": 0,
  "backend": "docker"
}