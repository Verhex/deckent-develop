{
  "workerId": "docker-203-009",
  "taskId": "203-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:18:21.375Z",
  "exitCode": 0,
  "backend": "docker"
}