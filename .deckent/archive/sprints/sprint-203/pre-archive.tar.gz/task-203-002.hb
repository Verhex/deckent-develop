{
  "workerId": "docker-203-002",
  "taskId": "203-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:22:32.142Z",
  "exitCode": 0,
  "backend": "docker"
}