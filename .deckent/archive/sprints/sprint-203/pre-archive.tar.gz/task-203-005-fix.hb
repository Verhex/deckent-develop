{
  "workerId": "docker-203-005-fix",
  "taskId": "203-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:30:16.357Z",
  "exitCode": 0,
  "backend": "docker"
}