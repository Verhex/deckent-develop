{
  "workerId": "docker-203-004",
  "taskId": "203-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:21:31.004Z",
  "exitCode": 0,
  "backend": "docker"
}