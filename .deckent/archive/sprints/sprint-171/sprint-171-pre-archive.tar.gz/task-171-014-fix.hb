{
  "workerId": "docker-171-014-fix",
  "taskId": "171-014-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T11:09:26.929Z",
  "exitCode": 0,
  "backend": "docker"
}