{
  "workerId": "docker-171-001",
  "taskId": "171-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:07:08.311Z",
  "exitCode": 0,
  "backend": "docker"
}