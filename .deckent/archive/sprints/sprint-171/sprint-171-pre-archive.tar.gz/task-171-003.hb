{
  "workerId": "docker-171-003",
  "taskId": "171-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:11:05.368Z",
  "exitCode": 0,
  "backend": "docker"
}