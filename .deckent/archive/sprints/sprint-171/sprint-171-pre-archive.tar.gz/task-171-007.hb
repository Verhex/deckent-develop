{
  "workerId": "docker-171-007",
  "taskId": "171-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:16:14.202Z",
  "exitCode": 0,
  "backend": "docker"
}