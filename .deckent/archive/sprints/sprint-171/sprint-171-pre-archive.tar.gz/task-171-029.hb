{
  "workerId": "docker-171-029",
  "taskId": "171-029",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T11:05:32.279Z",
  "exitCode": 0,
  "backend": "docker"
}