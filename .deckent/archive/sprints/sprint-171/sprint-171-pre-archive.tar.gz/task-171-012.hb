{
  "workerId": "docker-171-012",
  "taskId": "171-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:24:15.588Z",
  "exitCode": 0,
  "backend": "docker"
}