{
  "workerId": "docker-171-006",
  "taskId": "171-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:08:59.741Z",
  "exitCode": 0,
  "backend": "docker"
}