{
  "workerId": "docker-171-026",
  "taskId": "171-026",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:50:02.360Z",
  "exitCode": 0,
  "backend": "docker"
}