{
  "workerId": "docker-171-022",
  "taskId": "171-022",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:43:03.638Z",
  "exitCode": 0,
  "backend": "docker"
}