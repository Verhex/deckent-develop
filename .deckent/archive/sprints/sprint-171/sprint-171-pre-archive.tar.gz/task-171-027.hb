{
  "workerId": "docker-171-027",
  "taskId": "171-027",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:48:57.062Z",
  "exitCode": 0,
  "backend": "docker"
}