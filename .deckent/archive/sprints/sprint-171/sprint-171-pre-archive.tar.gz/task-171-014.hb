{
  "workerId": "docker-171-014",
  "taskId": "171-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:25:59.604Z",
  "exitCode": 0,
  "backend": "docker"
}