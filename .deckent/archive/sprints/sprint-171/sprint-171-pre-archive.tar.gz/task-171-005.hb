{
  "workerId": "docker-171-005",
  "taskId": "171-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:06:04.295Z",
  "exitCode": 0,
  "backend": "docker"
}