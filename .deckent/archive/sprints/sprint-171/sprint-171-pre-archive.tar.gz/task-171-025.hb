{
  "workerId": "docker-171-025",
  "taskId": "171-025",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:51:19.483Z",
  "exitCode": 0,
  "backend": "docker"
}