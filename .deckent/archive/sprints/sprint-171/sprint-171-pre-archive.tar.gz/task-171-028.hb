{
  "workerId": "docker-171-028",
  "taskId": "171-028",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:53:37.223Z",
  "exitCode": 0,
  "backend": "docker"
}