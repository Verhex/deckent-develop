{
  "workerId": "docker-171-002",
  "taskId": "171-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:07:08.147Z",
  "exitCode": 0,
  "backend": "docker"
}