{
  "workerId": "docker-171-020",
  "taskId": "171-020",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:32:48.870Z",
  "exitCode": 0,
  "backend": "docker"
}