{
  "workerId": "docker-171-011",
  "taskId": "171-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:18:52.102Z",
  "exitCode": 0,
  "backend": "docker"
}