{
  "workerId": "docker-171-008",
  "taskId": "171-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:16:38.402Z",
  "exitCode": 0,
  "backend": "docker"
}