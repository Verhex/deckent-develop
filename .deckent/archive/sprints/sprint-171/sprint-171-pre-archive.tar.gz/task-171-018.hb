{
  "workerId": "docker-171-018",
  "taskId": "171-018",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:37:25.442Z",
  "exitCode": 0,
  "backend": "docker"
}