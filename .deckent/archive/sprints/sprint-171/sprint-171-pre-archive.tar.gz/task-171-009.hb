{
  "workerId": "docker-171-009",
  "taskId": "171-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:19:34.187Z",
  "exitCode": 0,
  "backend": "docker"
}