{
  "workerId": "docker-171-019",
  "taskId": "171-019",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:36:13.708Z",
  "exitCode": 0,
  "backend": "docker"
}