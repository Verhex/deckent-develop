{
  "workerId": "docker-171-023-fix",
  "taskId": "171-023-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T11:15:22.050Z",
  "exitCode": 0,
  "backend": "docker"
}