{
  "workerId": "docker-171-004",
  "taskId": "171-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:06:52.463Z",
  "exitCode": 0,
  "backend": "docker"
}