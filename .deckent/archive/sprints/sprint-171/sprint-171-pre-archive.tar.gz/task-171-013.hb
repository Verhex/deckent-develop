{
  "workerId": "docker-171-013",
  "taskId": "171-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:30:10.331Z",
  "exitCode": 0,
  "backend": "docker"
}