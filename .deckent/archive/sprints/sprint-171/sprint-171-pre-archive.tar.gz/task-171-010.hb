{
  "workerId": "docker-171-010",
  "taskId": "171-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:15:54.725Z",
  "exitCode": 0,
  "backend": "docker"
}