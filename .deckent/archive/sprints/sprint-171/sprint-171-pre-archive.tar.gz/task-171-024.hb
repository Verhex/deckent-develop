{
  "workerId": "docker-171-024",
  "taskId": "171-024",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:46:57.073Z",
  "exitCode": 0,
  "backend": "docker"
}