{
  "workerId": "docker-171-021",
  "taskId": "171-021",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:40:25.060Z",
  "exitCode": 0,
  "backend": "docker"
}