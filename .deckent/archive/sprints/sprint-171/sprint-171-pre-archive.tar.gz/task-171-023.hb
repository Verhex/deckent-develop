{
  "workerId": "docker-171-023",
  "taskId": "171-023",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:44:56.100Z",
  "exitCode": 0,
  "backend": "docker"
}