{
  "workerId": "docker-171-015",
  "taskId": "171-015",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:25:24.720Z",
  "exitCode": 0,
  "backend": "docker"
}