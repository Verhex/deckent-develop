{
  "workerId": "docker-171-017",
  "taskId": "171-017",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:33:35.410Z",
  "exitCode": 0,
  "backend": "docker"
}