{
  "workerId": "docker-171-016",
  "taskId": "171-016",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-15T10:32:24.047Z",
  "exitCode": 0,
  "backend": "docker"
}