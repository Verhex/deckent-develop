{
  "workerId": "docker-205-008",
  "taskId": "205-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:47:55.987Z",
  "exitCode": 0,
  "backend": "docker"
}