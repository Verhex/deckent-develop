{
  "workerId": "docker-205-004-fix",
  "taskId": "205-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:51:55.840Z",
  "exitCode": 0,
  "backend": "docker"
}