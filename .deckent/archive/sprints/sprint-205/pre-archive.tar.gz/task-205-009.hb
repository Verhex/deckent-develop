{
  "workerId": "docker-205-009",
  "taskId": "205-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:49:08.857Z",
  "exitCode": 0,
  "backend": "docker"
}