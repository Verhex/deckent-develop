{
  "workerId": "docker-205-003",
  "taskId": "205-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:49:53.800Z",
  "exitCode": 0,
  "backend": "docker"
}