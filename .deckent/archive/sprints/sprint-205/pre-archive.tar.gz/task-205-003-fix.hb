{
  "workerId": "docker-205-003-fix",
  "taskId": "205-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:58:00.993Z",
  "exitCode": 0,
  "backend": "docker"
}