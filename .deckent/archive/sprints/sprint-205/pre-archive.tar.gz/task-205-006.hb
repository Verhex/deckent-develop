{
  "workerId": "docker-205-006",
  "taskId": "205-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:48:44.225Z",
  "exitCode": 0,
  "backend": "docker"
}