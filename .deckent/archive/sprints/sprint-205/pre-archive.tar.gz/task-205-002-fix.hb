{
  "workerId": "docker-205-002-fix",
  "taskId": "205-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:54:55.630Z",
  "exitCode": 0,
  "backend": "docker"
}