{
  "workerId": "docker-205-005",
  "taskId": "205-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:47:10.931Z",
  "exitCode": 0,
  "backend": "docker"
}