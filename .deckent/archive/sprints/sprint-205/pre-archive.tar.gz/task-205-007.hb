{
  "workerId": "docker-205-007",
  "taskId": "205-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:50:47.556Z",
  "exitCode": 0,
  "backend": "docker"
}