{
  "workerId": "docker-205-001",
  "taskId": "205-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:49:03.078Z",
  "exitCode": 0,
  "backend": "docker"
}