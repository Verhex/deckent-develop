{
  "workerId": "docker-205-004",
  "taskId": "205-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:49:02.860Z",
  "exitCode": 0,
  "backend": "docker"
}