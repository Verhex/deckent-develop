{
  "workerId": "docker-205-002",
  "taskId": "205-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T15:46:59.784Z",
  "exitCode": 0,
  "backend": "docker"
}