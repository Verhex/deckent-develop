{
  "workerId": "docker-193-001",
  "taskId": "193-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T14:07:14.407Z",
  "exitCode": 0,
  "backend": "docker"
}