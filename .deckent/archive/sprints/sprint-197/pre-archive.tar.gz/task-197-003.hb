{
  "workerId": "docker-197-003",
  "taskId": "197-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:17:28.298Z",
  "exitCode": 0,
  "backend": "docker"
}