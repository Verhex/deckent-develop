{
  "workerId": "docker-197-005",
  "taskId": "197-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:26:59.186Z",
  "exitCode": 0,
  "backend": "docker"
}