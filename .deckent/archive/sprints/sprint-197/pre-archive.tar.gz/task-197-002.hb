{
  "workerId": "docker-197-002",
  "taskId": "197-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:19:44.084Z",
  "exitCode": 0,
  "backend": "docker"
}