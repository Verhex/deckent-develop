{
  "workerId": "docker-197-004-fix",
  "taskId": "197-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:29:14.443Z",
  "exitCode": 0,
  "backend": "docker"
}