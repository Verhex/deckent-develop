{
  "workerId": "docker-197-003-fix",
  "taskId": "197-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:30:38.504Z",
  "exitCode": 0,
  "backend": "docker"
}