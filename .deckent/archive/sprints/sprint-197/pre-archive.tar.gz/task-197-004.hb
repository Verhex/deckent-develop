{
  "workerId": "docker-197-004",
  "taskId": "197-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:24:09.920Z",
  "exitCode": 0,
  "backend": "docker"
}