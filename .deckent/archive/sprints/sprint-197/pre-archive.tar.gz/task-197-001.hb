{
  "workerId": "docker-197-001",
  "taskId": "197-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:20:42.533Z",
  "exitCode": 0,
  "backend": "docker"
}