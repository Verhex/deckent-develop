{
  "workerId": "docker-197-001-fix",
  "taskId": "197-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T17:29:23.840Z",
  "exitCode": 0,
  "backend": "docker"
}