{
  "workerId": "docker-185-002",
  "taskId": "185-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T16:44:09.591Z",
  "exitCode": 0,
  "backend": "docker"
}