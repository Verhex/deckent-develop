{
  "workerId": "docker-185-001",
  "taskId": "185-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T16:45:03.847Z",
  "exitCode": 0,
  "backend": "docker"
}