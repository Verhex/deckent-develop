{
  "workerId": "docker-185-005",
  "taskId": "185-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T16:30:51.753Z",
  "exitCode": 0,
  "backend": "docker"
}