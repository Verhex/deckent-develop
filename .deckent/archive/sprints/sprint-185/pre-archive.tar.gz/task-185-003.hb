{
  "workerId": "docker-185-003",
  "taskId": "185-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T16:41:08.911Z",
  "exitCode": 0,
  "backend": "docker"
}