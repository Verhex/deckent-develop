{
  "workerId": "docker-185-005-fix",
  "taskId": "185-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T17:02:04.731Z",
  "exitCode": 0,
  "backend": "docker"
}