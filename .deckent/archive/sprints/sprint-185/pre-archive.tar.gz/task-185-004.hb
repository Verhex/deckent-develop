{
  "workerId": "docker-185-004",
  "taskId": "185-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T16:38:37.642Z",
  "exitCode": 0,
  "backend": "docker"
}