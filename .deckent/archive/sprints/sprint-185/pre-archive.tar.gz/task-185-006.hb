{
  "workerId": "docker-185-006",
  "taskId": "185-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T16:49:18.401Z",
  "exitCode": 0,
  "backend": "docker"
}