{
  "workerId": "docker-202-001-fix",
  "taskId": "202-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T13:45:38.546Z",
  "exitCode": 0,
  "backend": "docker"
}