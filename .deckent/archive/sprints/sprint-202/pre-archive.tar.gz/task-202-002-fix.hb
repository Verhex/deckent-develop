{
  "workerId": "docker-202-002-fix",
  "taskId": "202-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T13:45:04.574Z",
  "exitCode": 0,
  "backend": "docker"
}