{
  "workerId": "docker-202-002",
  "taskId": "202-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T13:31:54.585Z",
  "exitCode": 0,
  "backend": "docker"
}