{
  "workerId": "docker-202-004",
  "taskId": "202-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T13:07:05.160Z",
  "exitCode": 0,
  "backend": "docker"
}