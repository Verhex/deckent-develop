{
  "workerId": "docker-202-001",
  "taskId": "202-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T13:24:25.374Z",
  "exitCode": 0,
  "backend": "docker"
}