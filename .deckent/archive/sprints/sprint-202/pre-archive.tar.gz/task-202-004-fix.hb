{
  "workerId": "docker-202-004-fix",
  "taskId": "202-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T14:02:58.046Z",
  "exitCode": 0,
  "backend": "docker"
}