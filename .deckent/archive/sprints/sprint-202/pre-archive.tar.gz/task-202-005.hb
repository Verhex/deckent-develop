{
  "workerId": "docker-202-005",
  "taskId": "202-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T13:10:07.460Z",
  "exitCode": 0,
  "backend": "docker"
}