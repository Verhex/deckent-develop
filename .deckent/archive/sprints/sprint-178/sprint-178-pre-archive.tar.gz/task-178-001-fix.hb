{
  "workerId": "docker-178-001-fix",
  "taskId": "178-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:45:23.246Z",
  "exitCode": 0,
  "backend": "docker"
}