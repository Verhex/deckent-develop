{
  "workerId": "docker-178-001",
  "taskId": "178-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:26:39.808Z",
  "exitCode": 0,
  "backend": "docker"
}