{
  "workerId": "docker-178-003",
  "taskId": "178-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:21:24.979Z",
  "exitCode": 0,
  "backend": "docker"
}