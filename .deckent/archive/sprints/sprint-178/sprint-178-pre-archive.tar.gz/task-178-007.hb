{
  "workerId": "docker-178-007",
  "taskId": "178-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:20:24.743Z",
  "exitCode": 0,
  "backend": "docker"
}