{
  "workerId": "docker-178-005",
  "taskId": "178-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:42:03.602Z",
  "exitCode": 0,
  "backend": "docker"
}