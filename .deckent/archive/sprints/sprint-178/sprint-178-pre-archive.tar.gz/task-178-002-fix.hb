{
  "workerId": "docker-178-002-fix",
  "taskId": "178-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:46:04.455Z",
  "exitCode": 0,
  "backend": "docker"
}