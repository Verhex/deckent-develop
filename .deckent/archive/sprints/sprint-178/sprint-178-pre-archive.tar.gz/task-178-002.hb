{
  "workerId": "docker-178-002",
  "taskId": "178-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:19:31.431Z",
  "exitCode": 0,
  "backend": "docker"
}