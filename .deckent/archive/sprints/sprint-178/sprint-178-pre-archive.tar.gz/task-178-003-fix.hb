{
  "workerId": "docker-178-003-fix",
  "taskId": "178-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:43:55.187Z",
  "exitCode": 0,
  "backend": "docker"
}