{
  "workerId": "docker-178-004",
  "taskId": "178-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:27:40.163Z",
  "exitCode": 0,
  "backend": "docker"
}