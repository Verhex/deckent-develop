{
  "workerId": "docker-178-007-fix",
  "taskId": "178-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:55:17.995Z",
  "exitCode": 0,
  "backend": "docker"
}