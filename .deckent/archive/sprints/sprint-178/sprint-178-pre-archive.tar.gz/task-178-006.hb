{
  "workerId": "docker-178-006",
  "taskId": "178-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T11:30:59.311Z",
  "exitCode": 0,
  "backend": "docker"
}