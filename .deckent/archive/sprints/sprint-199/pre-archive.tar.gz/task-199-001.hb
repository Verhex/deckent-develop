{
  "workerId": "docker-199-001",
  "taskId": "199-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:14:20.464Z",
  "exitCode": 0,
  "backend": "docker"
}