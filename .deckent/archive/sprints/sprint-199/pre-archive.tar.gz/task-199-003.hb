{
  "workerId": "docker-199-003",
  "taskId": "199-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:10:18.165Z",
  "exitCode": 0,
  "backend": "docker"
}