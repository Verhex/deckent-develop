{
  "workerId": "docker-199-004",
  "taskId": "199-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:11:49.885Z",
  "exitCode": 0,
  "backend": "docker"
}