{
  "workerId": "docker-199-009",
  "taskId": "199-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:19:28.096Z",
  "exitCode": 0,
  "backend": "docker"
}