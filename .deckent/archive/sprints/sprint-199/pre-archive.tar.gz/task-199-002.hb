{
  "workerId": "docker-199-002",
  "taskId": "199-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:15:01.351Z",
  "exitCode": 0,
  "backend": "docker"
}