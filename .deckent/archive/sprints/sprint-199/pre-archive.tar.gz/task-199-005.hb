{
  "workerId": "docker-199-005",
  "taskId": "199-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:00:34.483Z",
  "exitCode": 0,
  "backend": "docker"
}