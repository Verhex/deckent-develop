{
  "workerId": "docker-199-008",
  "taskId": "199-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:06:11.788Z",
  "exitCode": 0,
  "backend": "docker"
}