{
  "workerId": "docker-199-006",
  "taskId": "199-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:39:14.706Z",
  "exitCode": 0,
  "backend": "docker"
}