{
  "workerId": "docker-199-007",
  "taskId": "199-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:02:05.664Z",
  "exitCode": 0,
  "backend": "docker"
}