{
  "workerId": "docker-181-002",
  "taskId": "181-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T06:16:25.959Z",
  "exitCode": 0,
  "backend": "docker"
}