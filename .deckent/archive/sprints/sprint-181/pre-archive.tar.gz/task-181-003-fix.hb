{
  "workerId": "docker-181-003-fix",
  "taskId": "181-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T06:20:28.440Z",
  "exitCode": 0,
  "backend": "docker"
}