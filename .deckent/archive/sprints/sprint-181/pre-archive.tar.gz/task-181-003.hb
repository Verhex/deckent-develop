{
  "workerId": "docker-181-003",
  "taskId": "181-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T06:04:36.732Z",
  "exitCode": 0,
  "backend": "docker"
}