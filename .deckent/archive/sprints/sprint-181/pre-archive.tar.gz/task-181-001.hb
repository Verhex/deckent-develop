{
  "workerId": "docker-181-001",
  "taskId": "181-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T06:10:41.184Z",
  "exitCode": 0,
  "backend": "docker"
}