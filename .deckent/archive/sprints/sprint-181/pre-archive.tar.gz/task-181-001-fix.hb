{
  "workerId": "docker-181-001-fix",
  "taskId": "181-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T06:23:51.030Z",
  "exitCode": 0,
  "backend": "docker"
}