{
  "workerId": "docker-198-003-fix",
  "taskId": "198-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:52:10.461Z",
  "exitCode": 0,
  "backend": "docker"
}