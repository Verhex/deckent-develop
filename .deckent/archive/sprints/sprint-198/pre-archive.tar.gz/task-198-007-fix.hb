{
  "workerId": "docker-198-007-fix",
  "taskId": "198-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T01:03:11.635Z",
  "exitCode": 0,
  "backend": "docker"
}