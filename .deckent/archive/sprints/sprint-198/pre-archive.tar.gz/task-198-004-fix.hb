{
  "workerId": "docker-198-004-fix",
  "taskId": "198-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:57:10.086Z",
  "exitCode": 0,
  "backend": "docker"
}