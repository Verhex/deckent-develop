{
  "workerId": "docker-198-005-fix",
  "taskId": "198-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:52:10.638Z",
  "exitCode": 0,
  "backend": "docker"
}