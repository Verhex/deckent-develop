{
  "workerId": "docker-198-003",
  "taskId": "198-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:38.119Z",
  "exitCode": 0,
  "backend": "docker"
}