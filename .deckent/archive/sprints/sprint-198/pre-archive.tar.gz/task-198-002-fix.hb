{
  "workerId": "docker-198-002-fix",
  "taskId": "198-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:52:03.087Z",
  "exitCode": 0,
  "backend": "docker"
}