{
  "workerId": "docker-198-010-fix",
  "taskId": "198-010-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:57:14.151Z",
  "exitCode": 0,
  "backend": "docker"
}