{
  "workerId": "docker-198-001",
  "taskId": "198-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:38.343Z",
  "exitCode": 0,
  "backend": "docker"
}