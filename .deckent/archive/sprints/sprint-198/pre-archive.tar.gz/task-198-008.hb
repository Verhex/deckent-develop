{
  "workerId": "docker-198-008",
  "taskId": "198-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:42.399Z",
  "exitCode": 0,
  "backend": "docker"
}