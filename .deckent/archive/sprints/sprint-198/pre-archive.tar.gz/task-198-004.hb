{
  "workerId": "docker-198-004",
  "taskId": "198-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:46:01.680Z",
  "exitCode": 0,
  "backend": "docker"
}