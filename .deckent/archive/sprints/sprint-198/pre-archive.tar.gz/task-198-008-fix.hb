{
  "workerId": "docker-198-008-fix",
  "taskId": "198-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:57:10.288Z",
  "exitCode": 0,
  "backend": "docker"
}