{
  "workerId": "docker-198-002",
  "taskId": "198-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:37.931Z",
  "exitCode": 0,
  "backend": "docker"
}