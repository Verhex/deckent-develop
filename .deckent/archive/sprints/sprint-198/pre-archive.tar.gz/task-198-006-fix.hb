{
  "workerId": "docker-198-006-fix",
  "taskId": "198-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:52:02.898Z",
  "exitCode": 0,
  "backend": "docker"
}