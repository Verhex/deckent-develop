{
  "workerId": "docker-198-005",
  "taskId": "198-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:42.185Z",
  "exitCode": 0,
  "backend": "docker"
}