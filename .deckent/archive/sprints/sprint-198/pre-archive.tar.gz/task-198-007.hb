{
  "workerId": "docker-198-007",
  "taskId": "198-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:51:55.363Z",
  "exitCode": 0,
  "backend": "docker"
}