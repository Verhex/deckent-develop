{
  "workerId": "docker-198-009",
  "taskId": "198-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:50.414Z",
  "exitCode": 0,
  "backend": "docker"
}