{
  "workerId": "docker-198-006",
  "taskId": "198-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:36.389Z",
  "exitCode": 0,
  "backend": "docker"
}