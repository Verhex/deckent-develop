{
  "workerId": "docker-198-010",
  "taskId": "198-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:40:54.398Z",
  "exitCode": 0,
  "backend": "docker"
}