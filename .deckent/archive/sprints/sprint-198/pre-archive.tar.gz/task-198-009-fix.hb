{
  "workerId": "docker-198-009-fix",
  "taskId": "198-009-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:52:14.498Z",
  "exitCode": 0,
  "backend": "docker"
}