{
  "workerId": "docker-198-001-fix",
  "taskId": "198-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T00:51:55.544Z",
  "exitCode": 0,
  "backend": "docker"
}