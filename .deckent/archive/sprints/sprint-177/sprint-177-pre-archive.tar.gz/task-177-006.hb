{
  "workerId": "docker-177-006",
  "taskId": "177-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:42:34.932Z",
  "exitCode": 0,
  "backend": "docker"
}