{
  "workerId": "docker-177-005",
  "taskId": "177-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:30:21.664Z",
  "exitCode": 0,
  "backend": "docker"
}