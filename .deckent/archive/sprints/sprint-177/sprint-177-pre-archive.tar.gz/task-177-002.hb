{
  "workerId": "docker-177-002",
  "taskId": "177-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:30:49.766Z",
  "exitCode": 0,
  "backend": "docker"
}