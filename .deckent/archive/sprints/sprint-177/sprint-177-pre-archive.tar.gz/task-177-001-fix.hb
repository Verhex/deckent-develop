{
  "workerId": "docker-177-001-fix",
  "taskId": "177-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:46:13.476Z",
  "exitCode": 0,
  "backend": "docker"
}