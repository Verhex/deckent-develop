{
  "workerId": "docker-177-003",
  "taskId": "177-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:39:47.772Z",
  "exitCode": 0,
  "backend": "docker"
}