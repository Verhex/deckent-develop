{
  "workerId": "docker-177-004",
  "taskId": "177-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:41:35.596Z",
  "exitCode": 0,
  "backend": "docker"
}