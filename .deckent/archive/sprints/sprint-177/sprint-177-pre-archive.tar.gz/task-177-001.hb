{
  "workerId": "docker-177-001",
  "taskId": "177-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-20T10:21:05.710Z",
  "exitCode": 0,
  "backend": "docker"
}