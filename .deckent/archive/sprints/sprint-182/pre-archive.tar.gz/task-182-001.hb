{
  "workerId": "docker-182-001",
  "taskId": "182-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:14:05.040Z",
  "exitCode": 0,
  "backend": "docker"
}