{
  "workerId": "docker-182-003",
  "taskId": "182-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:14:08.794Z",
  "exitCode": 0,
  "backend": "docker"
}