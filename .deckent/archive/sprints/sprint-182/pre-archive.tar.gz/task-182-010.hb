{
  "workerId": "docker-182-010",
  "taskId": "182-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:31:01.810Z",
  "exitCode": 0,
  "backend": "docker"
}