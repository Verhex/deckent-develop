{
  "workerId": "docker-182-017",
  "taskId": "182-017",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:25:23.285Z",
  "exitCode": 0,
  "backend": "docker"
}