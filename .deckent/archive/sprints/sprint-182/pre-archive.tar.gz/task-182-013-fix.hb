{
  "workerId": "docker-182-013-fix",
  "taskId": "182-013-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:45:03.215Z",
  "exitCode": 0,
  "backend": "docker"
}