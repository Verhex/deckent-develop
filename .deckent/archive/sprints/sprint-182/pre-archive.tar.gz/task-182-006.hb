{
  "workerId": "docker-182-006",
  "taskId": "182-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:18:05.348Z",
  "exitCode": 0,
  "backend": "docker"
}