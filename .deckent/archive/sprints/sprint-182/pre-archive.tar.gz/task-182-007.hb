{
  "workerId": "docker-182-007",
  "taskId": "182-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:12:10.609Z",
  "exitCode": 0,
  "backend": "docker"
}