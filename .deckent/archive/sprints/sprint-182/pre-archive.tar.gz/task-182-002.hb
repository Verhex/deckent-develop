{
  "workerId": "docker-182-002",
  "taskId": "182-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:12:06.149Z",
  "exitCode": 0,
  "backend": "docker"
}