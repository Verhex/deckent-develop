{
  "workerId": "docker-182-001-fix",
  "taskId": "182-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:51:15.261Z",
  "exitCode": 0,
  "backend": "docker"
}