{
  "workerId": "docker-182-003-fix",
  "taskId": "182-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:43:26.446Z",
  "exitCode": 0,
  "backend": "docker"
}