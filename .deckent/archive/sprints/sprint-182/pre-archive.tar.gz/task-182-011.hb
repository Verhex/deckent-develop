{
  "workerId": "docker-182-011",
  "taskId": "182-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:46:28.384Z",
  "exitCode": 0,
  "backend": "docker"
}