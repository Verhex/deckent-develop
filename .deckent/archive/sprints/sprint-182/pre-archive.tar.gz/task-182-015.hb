{
  "workerId": "docker-182-015",
  "taskId": "182-015",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:35:39.701Z",
  "exitCode": 0,
  "backend": "docker"
}