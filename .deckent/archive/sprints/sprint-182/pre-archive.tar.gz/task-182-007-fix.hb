{
  "workerId": "docker-182-007-fix",
  "taskId": "182-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:54:17.120Z",
  "exitCode": 0,
  "backend": "docker"
}