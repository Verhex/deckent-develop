{
  "workerId": "docker-182-008",
  "taskId": "182-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:29:30.016Z",
  "exitCode": 0,
  "backend": "docker"
}