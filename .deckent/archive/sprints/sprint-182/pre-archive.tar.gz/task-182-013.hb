{
  "workerId": "docker-182-013",
  "taskId": "182-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:25:19.076Z",
  "exitCode": 0,
  "backend": "docker"
}