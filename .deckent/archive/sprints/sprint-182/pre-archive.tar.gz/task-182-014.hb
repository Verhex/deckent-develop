{
  "workerId": "docker-182-014",
  "taskId": "182-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:20:21.844Z",
  "exitCode": 0,
  "backend": "docker"
}