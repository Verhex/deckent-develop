{
  "workerId": "docker-182-014-fix",
  "taskId": "182-014-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:43:55.311Z",
  "exitCode": 0,
  "backend": "docker"
}