{
  "workerId": "docker-182-009",
  "taskId": "182-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:24:33.429Z",
  "exitCode": 0,
  "backend": "docker"
}