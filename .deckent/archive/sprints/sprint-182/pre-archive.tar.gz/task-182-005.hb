{
  "workerId": "docker-182-005",
  "taskId": "182-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:14:42.477Z",
  "exitCode": 0,
  "backend": "docker"
}