{
  "workerId": "docker-182-016",
  "taskId": "182-016",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:36:42.875Z",
  "exitCode": 0,
  "backend": "docker"
}