{
  "workerId": "docker-182-011-fix",
  "taskId": "182-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:57:51.861Z",
  "exitCode": 0,
  "backend": "docker"
}