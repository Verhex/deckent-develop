{
  "workerId": "docker-182-005-fix",
  "taskId": "182-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:45:43.688Z",
  "exitCode": 0,
  "backend": "docker"
}