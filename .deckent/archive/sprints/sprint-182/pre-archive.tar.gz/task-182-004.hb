{
  "workerId": "docker-182-004",
  "taskId": "182-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:19:03.636Z",
  "exitCode": 0,
  "backend": "docker"
}