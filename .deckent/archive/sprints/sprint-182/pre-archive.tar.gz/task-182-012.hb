{
  "workerId": "docker-182-012",
  "taskId": "182-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T10:30:22.673Z",
  "exitCode": 0,
  "backend": "docker"
}