{
  "workerId": "docker-175-015",
  "taskId": "175-015",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:17:07.495Z",
  "exitCode": 0,
  "backend": "docker"
}