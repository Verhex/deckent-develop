{
  "workerId": "docker-175-005-xfix",
  "taskId": "175-005-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:34:54.974Z",
  "exitCode": 0,
  "backend": "docker"
}