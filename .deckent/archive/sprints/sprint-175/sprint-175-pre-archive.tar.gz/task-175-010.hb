{
  "workerId": "docker-175-010",
  "taskId": "175-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:21:13.739Z",
  "exitCode": 0,
  "backend": "docker"
}