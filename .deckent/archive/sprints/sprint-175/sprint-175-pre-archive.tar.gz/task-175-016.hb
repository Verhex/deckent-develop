{
  "workerId": "docker-175-016",
  "taskId": "175-016",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:17:03.820Z",
  "exitCode": 0,
  "backend": "docker"
}