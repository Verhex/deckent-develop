{
  "workerId": "docker-175-007",
  "taskId": "175-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:11:21.068Z",
  "exitCode": 0,
  "backend": "docker"
}