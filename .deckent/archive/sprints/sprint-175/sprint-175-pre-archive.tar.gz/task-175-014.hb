{
  "workerId": "docker-175-014",
  "taskId": "175-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:13:32.001Z",
  "exitCode": 0,
  "backend": "docker"
}