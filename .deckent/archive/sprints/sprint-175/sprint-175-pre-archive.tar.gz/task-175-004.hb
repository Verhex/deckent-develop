{
  "workerId": "docker-175-004",
  "taskId": "175-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T21:58:49.254Z",
  "exitCode": 0,
  "backend": "docker"
}