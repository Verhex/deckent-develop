{
  "workerId": "docker-175-016-fix",
  "taskId": "175-016-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:47:52.225Z",
  "exitCode": 0,
  "backend": "docker"
}