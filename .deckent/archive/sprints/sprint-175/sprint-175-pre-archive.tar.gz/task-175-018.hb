{
  "workerId": "docker-175-018",
  "taskId": "175-018",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:24:33.126Z",
  "exitCode": 0,
  "backend": "docker"
}