{
  "workerId": "docker-175-012",
  "taskId": "175-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:08:51.376Z",
  "exitCode": 0,
  "backend": "docker"
}