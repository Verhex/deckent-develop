{
  "workerId": "docker-175-020",
  "taskId": "175-020",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:36:04.681Z",
  "exitCode": 0,
  "backend": "docker"
}