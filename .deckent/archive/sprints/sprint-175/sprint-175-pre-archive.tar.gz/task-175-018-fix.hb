{
  "workerId": "docker-175-018-fix",
  "taskId": "175-018-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:45:34.044Z",
  "exitCode": 0,
  "backend": "docker"
}