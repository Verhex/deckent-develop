{
  "workerId": "docker-175-009",
  "taskId": "175-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:06:40.719Z",
  "exitCode": 0,
  "backend": "docker"
}