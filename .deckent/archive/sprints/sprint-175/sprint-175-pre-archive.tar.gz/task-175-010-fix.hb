{
  "workerId": "docker-175-010-fix",
  "taskId": "175-010-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:42:56.054Z",
  "exitCode": 0,
  "backend": "docker"
}