{
  "workerId": "docker-175-006-fix",
  "taskId": "175-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:32:44.277Z",
  "exitCode": 0,
  "backend": "docker"
}