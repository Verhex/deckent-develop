{
  "workerId": "docker-175-017",
  "taskId": "175-017",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:17:29.212Z",
  "exitCode": 0,
  "backend": "docker"
}