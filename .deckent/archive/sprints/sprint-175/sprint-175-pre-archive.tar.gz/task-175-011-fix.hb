{
  "workerId": "docker-175-011-fix",
  "taskId": "175-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:39:23.558Z",
  "exitCode": 0,
  "backend": "docker"
}