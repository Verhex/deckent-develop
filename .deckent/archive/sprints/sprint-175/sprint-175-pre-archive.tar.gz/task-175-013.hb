{
  "workerId": "docker-175-013",
  "taskId": "175-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:11:47.536Z",
  "exitCode": 0,
  "backend": "docker"
}