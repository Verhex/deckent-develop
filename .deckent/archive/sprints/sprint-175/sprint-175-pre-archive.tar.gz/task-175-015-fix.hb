{
  "workerId": "docker-175-015-fix",
  "taskId": "175-015-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:50:23.772Z",
  "exitCode": 0,
  "backend": "docker"
}