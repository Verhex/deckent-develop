{
  "workerId": "docker-175-008-fix",
  "taskId": "175-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:40:08.391Z",
  "exitCode": 0,
  "backend": "docker"
}