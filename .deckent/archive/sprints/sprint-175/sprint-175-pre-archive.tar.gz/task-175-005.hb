{
  "workerId": "docker-175-005",
  "taskId": "175-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T21:59:26.946Z",
  "exitCode": 0,
  "backend": "docker"
}