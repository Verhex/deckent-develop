{
  "workerId": "docker-175-008",
  "taskId": "175-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:02:59.128Z",
  "exitCode": 0,
  "backend": "docker"
}