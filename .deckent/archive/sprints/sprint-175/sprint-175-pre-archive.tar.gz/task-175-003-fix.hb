{
  "workerId": "docker-175-003-fix",
  "taskId": "175-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:39:43.223Z",
  "exitCode": 0,
  "backend": "docker"
}