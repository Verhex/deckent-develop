{
  "workerId": "docker-175-006",
  "taskId": "175-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:02:15.747Z",
  "exitCode": 0,
  "backend": "docker"
}