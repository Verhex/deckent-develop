{
  "workerId": "docker-175-014-fix",
  "taskId": "175-014-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:45:56.685Z",
  "exitCode": 0,
  "backend": "docker"
}