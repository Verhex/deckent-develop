{
  "workerId": "docker-175-001",
  "taskId": "175-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:23:30.492Z",
  "exitCode": 0,
  "backend": "docker"
}