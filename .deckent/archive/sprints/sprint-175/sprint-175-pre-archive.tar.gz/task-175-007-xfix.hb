{
  "workerId": "docker-175-007-xfix",
  "taskId": "175-007-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:40:59.031Z",
  "exitCode": 0,
  "backend": "docker"
}