{
  "workerId": "docker-175-009-fix",
  "taskId": "175-009-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:41:19.318Z",
  "exitCode": 0,
  "backend": "docker"
}