{
  "workerId": "docker-175-002",
  "taskId": "175-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:00:59.804Z",
  "exitCode": 0,
  "backend": "docker"
}