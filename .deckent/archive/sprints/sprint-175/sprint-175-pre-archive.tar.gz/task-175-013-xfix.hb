{
  "workerId": "docker-175-013-xfix",
  "taskId": "175-013-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:47:44.877Z",
  "exitCode": 0,
  "backend": "docker"
}