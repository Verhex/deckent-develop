{
  "workerId": "docker-175-004-xfix",
  "taskId": "175-004-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:34:31.903Z",
  "exitCode": 0,
  "backend": "docker"
}