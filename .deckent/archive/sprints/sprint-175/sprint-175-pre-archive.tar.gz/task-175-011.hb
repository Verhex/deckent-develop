{
  "workerId": "docker-175-011",
  "taskId": "175-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:13:39.511Z",
  "exitCode": 0,
  "backend": "docker"
}