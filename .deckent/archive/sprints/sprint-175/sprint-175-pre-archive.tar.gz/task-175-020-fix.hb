{
  "workerId": "docker-175-020-fix",
  "taskId": "175-020-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T23:02:05.888Z",
  "exitCode": 0,
  "backend": "docker"
}