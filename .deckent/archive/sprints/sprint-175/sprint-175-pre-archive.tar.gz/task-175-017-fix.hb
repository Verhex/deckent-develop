{
  "workerId": "docker-175-017-fix",
  "taskId": "175-017-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:48:25.329Z",
  "exitCode": 0,
  "backend": "docker"
}