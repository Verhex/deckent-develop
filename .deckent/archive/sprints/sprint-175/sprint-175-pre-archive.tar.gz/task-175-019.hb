{
  "workerId": "docker-175-019",
  "taskId": "175-019",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:21:35.219Z",
  "exitCode": 0,
  "backend": "docker"
}