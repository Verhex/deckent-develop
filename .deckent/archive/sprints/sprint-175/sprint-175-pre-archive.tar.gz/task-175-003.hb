{
  "workerId": "docker-175-003",
  "taskId": "175-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:06:57.426Z",
  "exitCode": 0,
  "backend": "docker"
}