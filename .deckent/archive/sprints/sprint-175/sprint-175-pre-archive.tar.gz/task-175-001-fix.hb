{
  "workerId": "docker-175-001-fix",
  "taskId": "175-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-19T22:37:22.985Z",
  "exitCode": 0,
  "backend": "docker"
}