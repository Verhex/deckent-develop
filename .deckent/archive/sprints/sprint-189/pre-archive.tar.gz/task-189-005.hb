{
  "workerId": "docker-189-005",
  "taskId": "189-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:04:44.262Z",
  "exitCode": 0,
  "backend": "docker"
}