{
  "workerId": "docker-189-012-fix",
  "taskId": "189-012-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:37:05.145Z",
  "exitCode": 0,
  "backend": "docker"
}