{
  "workerId": "docker-189-013",
  "taskId": "189-013",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-22T23:14:46.108Z",
  "exitCode": 137,
  "backend": "docker"
}