{
  "workerId": "docker-189-016",
  "taskId": "189-016",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:28:18.987Z",
  "exitCode": 0,
  "backend": "docker"
}