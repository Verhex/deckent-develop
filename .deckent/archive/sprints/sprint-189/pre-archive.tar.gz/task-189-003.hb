{
  "workerId": "docker-189-003",
  "taskId": "189-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:27:03.820Z",
  "exitCode": 0,
  "backend": "docker"
}