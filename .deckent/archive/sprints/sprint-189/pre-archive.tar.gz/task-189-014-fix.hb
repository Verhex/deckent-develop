{
  "workerId": "docker-189-014-fix",
  "taskId": "189-014-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:35:00.865Z",
  "exitCode": 0,
  "backend": "docker"
}