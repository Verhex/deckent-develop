{
  "workerId": "docker-189-013-fix",
  "taskId": "189-013-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:32:48.462Z",
  "exitCode": 0,
  "backend": "docker"
}