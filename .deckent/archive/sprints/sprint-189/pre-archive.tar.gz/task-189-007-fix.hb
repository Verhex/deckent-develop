{
  "workerId": "docker-189-007-fix",
  "taskId": "189-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:44:05.951Z",
  "exitCode": 0,
  "backend": "docker"
}