{
  "workerId": "docker-189-007",
  "taskId": "189-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:04:54.197Z",
  "exitCode": 0,
  "backend": "docker"
}