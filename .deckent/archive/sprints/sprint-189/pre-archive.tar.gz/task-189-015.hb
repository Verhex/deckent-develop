{
  "workerId": "docker-189-015",
  "taskId": "189-015",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-22T23:17:44.463Z",
  "exitCode": 137,
  "backend": "docker"
}