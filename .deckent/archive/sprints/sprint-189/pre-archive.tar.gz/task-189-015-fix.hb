{
  "workerId": "docker-189-015-fix",
  "taskId": "189-015-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:42:08.965Z",
  "exitCode": 0,
  "backend": "docker"
}