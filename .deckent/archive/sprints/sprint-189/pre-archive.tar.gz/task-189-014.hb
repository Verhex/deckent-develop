{
  "workerId": "docker-189-014",
  "taskId": "189-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:21:59.525Z",
  "exitCode": 0,
  "backend": "docker"
}