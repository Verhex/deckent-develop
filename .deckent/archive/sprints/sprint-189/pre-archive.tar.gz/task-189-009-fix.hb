{
  "workerId": "docker-189-009-fix",
  "taskId": "189-009-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:33:47.749Z",
  "exitCode": 0,
  "backend": "docker"
}