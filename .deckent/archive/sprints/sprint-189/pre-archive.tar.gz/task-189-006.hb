{
  "workerId": "docker-189-006",
  "taskId": "189-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:13:45.957Z",
  "exitCode": 0,
  "backend": "docker"
}