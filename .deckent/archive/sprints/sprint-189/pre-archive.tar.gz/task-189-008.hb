{
  "workerId": "docker-189-008",
  "taskId": "189-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:17:43.856Z",
  "exitCode": 0,
  "backend": "docker"
}