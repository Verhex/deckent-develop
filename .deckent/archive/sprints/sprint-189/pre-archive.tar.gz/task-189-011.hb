{
  "workerId": "docker-189-011",
  "taskId": "189-011",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-22T23:14:14.835Z",
  "exitCode": 137,
  "backend": "docker"
}