{
  "workerId": "docker-189-009",
  "taskId": "189-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:29:53.709Z",
  "exitCode": 0,
  "backend": "docker"
}