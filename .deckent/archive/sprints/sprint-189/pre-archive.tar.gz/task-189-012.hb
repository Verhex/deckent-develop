{
  "workerId": "docker-189-012",
  "taskId": "189-012",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-22T23:14:35.386Z",
  "exitCode": 137,
  "backend": "docker"
}