{
  "workerId": "docker-189-002",
  "taskId": "189-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:18:01.588Z",
  "exitCode": 0,
  "backend": "docker"
}