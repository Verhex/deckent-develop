{
  "workerId": "docker-189-010",
  "taskId": "189-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:18:01.398Z",
  "exitCode": 0,
  "backend": "docker"
}