{
  "workerId": "docker-189-011-fix",
  "taskId": "189-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T23:36:20.803Z",
  "exitCode": 0,
  "backend": "docker"
}