{
  "workerId": "docker-183-007",
  "taskId": "183-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:17:31.106Z",
  "exitCode": 0,
  "backend": "docker"
}