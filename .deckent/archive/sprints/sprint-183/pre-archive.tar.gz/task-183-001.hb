{
  "workerId": "docker-183-001",
  "taskId": "183-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:19:09.572Z",
  "exitCode": 0,
  "backend": "docker"
}