{
  "workerId": "docker-183-007-fix",
  "taskId": "183-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:32:03.183Z",
  "exitCode": 0,
  "backend": "docker"
}