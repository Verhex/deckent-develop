{
  "workerId": "docker-183-006",
  "taskId": "183-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:12:45.049Z",
  "exitCode": 0,
  "backend": "docker"
}