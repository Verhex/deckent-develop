{
  "workerId": "docker-183-003",
  "taskId": "183-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:24:41.197Z",
  "exitCode": 0,
  "backend": "docker"
}