{
  "workerId": "docker-183-004",
  "taskId": "183-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:24:43.850Z",
  "exitCode": 0,
  "backend": "docker"
}