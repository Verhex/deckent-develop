{
  "workerId": "docker-183-010",
  "taskId": "183-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:27:57.312Z",
  "exitCode": 0,
  "backend": "docker"
}