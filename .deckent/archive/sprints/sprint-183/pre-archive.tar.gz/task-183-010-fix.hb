{
  "workerId": "docker-183-010-fix",
  "taskId": "183-010-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:36:36.265Z",
  "exitCode": 0,
  "backend": "docker"
}