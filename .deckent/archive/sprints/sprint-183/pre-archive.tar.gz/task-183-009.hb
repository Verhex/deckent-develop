{
  "workerId": "docker-183-009",
  "taskId": "183-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:21:17.973Z",
  "exitCode": 0,
  "backend": "docker"
}