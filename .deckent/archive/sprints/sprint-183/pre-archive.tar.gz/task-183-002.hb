{
  "workerId": "docker-183-002",
  "taskId": "183-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:21:10.330Z",
  "exitCode": 0,
  "backend": "docker"
}