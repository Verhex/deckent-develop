{
  "workerId": "docker-183-008",
  "taskId": "183-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:23:18.757Z",
  "exitCode": 0,
  "backend": "docker"
}