{
  "workerId": "docker-183-005",
  "taskId": "183-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:20:41.035Z",
  "exitCode": 0,
  "backend": "docker"
}