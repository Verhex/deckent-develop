{
  "workerId": "docker-183-008-fix",
  "taskId": "183-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T12:32:05.319Z",
  "exitCode": 0,
  "backend": "docker"
}