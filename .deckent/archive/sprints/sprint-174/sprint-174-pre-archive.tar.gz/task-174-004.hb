{
  "workerId": "docker-174-004",
  "taskId": "174-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:19:09.820Z",
  "exitCode": 0,
  "backend": "docker"
}