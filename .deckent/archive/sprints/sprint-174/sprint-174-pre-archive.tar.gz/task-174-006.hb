{
  "workerId": "docker-174-006",
  "taskId": "174-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:23:42.726Z",
  "exitCode": 0,
  "backend": "docker"
}