{
  "workerId": "docker-174-002",
  "taskId": "174-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:15:05.454Z",
  "exitCode": 0,
  "backend": "docker"
}