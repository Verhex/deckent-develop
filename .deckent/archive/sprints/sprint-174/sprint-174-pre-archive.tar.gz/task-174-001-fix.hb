{
  "workerId": "docker-174-001-fix",
  "taskId": "174-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:28:04.985Z",
  "exitCode": 0,
  "backend": "docker"
}