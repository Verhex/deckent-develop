{
  "workerId": "docker-174-003",
  "taskId": "174-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:17:29.145Z",
  "exitCode": 0,
  "backend": "docker"
}