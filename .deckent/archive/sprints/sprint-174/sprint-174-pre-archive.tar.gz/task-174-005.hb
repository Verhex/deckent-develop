{
  "workerId": "docker-174-005",
  "taskId": "174-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:20:41.813Z",
  "exitCode": 0,
  "backend": "docker"
}