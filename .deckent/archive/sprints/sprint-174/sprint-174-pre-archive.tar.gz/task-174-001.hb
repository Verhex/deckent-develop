{
  "workerId": "docker-174-001",
  "taskId": "174-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T20:11:52.342Z",
  "exitCode": 0,
  "backend": "docker"
}