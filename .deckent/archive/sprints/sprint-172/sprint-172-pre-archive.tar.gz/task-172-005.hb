{
  "workerId": "docker-172-005",
  "taskId": "172-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:03:48.626Z",
  "exitCode": 0,
  "backend": "docker"
}