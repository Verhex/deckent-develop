{
  "workerId": "docker-172-006",
  "taskId": "172-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:51:16.249Z",
  "exitCode": 0,
  "backend": "docker"
}