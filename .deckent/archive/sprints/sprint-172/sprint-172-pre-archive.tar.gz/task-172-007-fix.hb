{
  "workerId": "docker-172-007-fix",
  "taskId": "172-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:32:27.844Z",
  "exitCode": 0,
  "backend": "docker"
}