{
  "workerId": "docker-172-006-fix",
  "taskId": "172-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:22:59.477Z",
  "exitCode": 0,
  "backend": "docker"
}