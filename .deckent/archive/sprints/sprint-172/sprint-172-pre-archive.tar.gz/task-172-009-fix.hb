{
  "workerId": "docker-172-009-fix",
  "taskId": "172-009-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:10:17.705Z",
  "exitCode": 0,
  "backend": "docker"
}