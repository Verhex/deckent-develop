{
  "workerId": "docker-172-010",
  "taskId": "172-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:55:01.117Z",
  "exitCode": 0,
  "backend": "docker"
}