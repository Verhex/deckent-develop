{
  "workerId": "docker-172-004",
  "taskId": "172-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:46:31.009Z",
  "exitCode": 0,
  "backend": "docker"
}