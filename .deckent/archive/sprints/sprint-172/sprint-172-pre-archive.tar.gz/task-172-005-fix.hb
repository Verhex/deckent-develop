{
  "workerId": "docker-172-005-fix",
  "taskId": "172-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:14:42.332Z",
  "exitCode": 0,
  "backend": "docker"
}