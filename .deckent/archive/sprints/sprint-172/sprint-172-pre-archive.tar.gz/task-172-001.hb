{
  "workerId": "docker-172-001",
  "taskId": "172-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:39:50.508Z",
  "exitCode": 0,
  "backend": "docker"
}