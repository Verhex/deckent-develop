{
  "workerId": "docker-172-008-fix",
  "taskId": "172-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:07:38.691Z",
  "exitCode": 0,
  "backend": "docker"
}