{
  "workerId": "docker-172-011",
  "taskId": "172-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T05:02:08.633Z",
  "exitCode": 0,
  "backend": "docker"
}