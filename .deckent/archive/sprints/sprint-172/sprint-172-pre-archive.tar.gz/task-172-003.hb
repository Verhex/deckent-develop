{
  "workerId": "docker-172-003",
  "taskId": "172-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:31:35.274Z",
  "exitCode": 0,
  "backend": "docker"
}