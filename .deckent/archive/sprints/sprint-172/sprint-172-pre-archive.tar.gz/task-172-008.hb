{
  "workerId": "docker-172-008",
  "taskId": "172-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:49:13.844Z",
  "exitCode": 0,
  "backend": "docker"
}