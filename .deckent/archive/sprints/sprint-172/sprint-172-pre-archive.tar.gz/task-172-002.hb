{
  "workerId": "docker-172-002",
  "taskId": "172-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:41:14.816Z",
  "exitCode": 0,
  "backend": "docker"
}