{
  "workerId": "docker-172-007",
  "taskId": "172-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:48:46.855Z",
  "exitCode": 0,
  "backend": "docker"
}