{
  "workerId": "docker-172-012",
  "taskId": "172-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:56:23.715Z",
  "exitCode": 0,
  "backend": "docker"
}