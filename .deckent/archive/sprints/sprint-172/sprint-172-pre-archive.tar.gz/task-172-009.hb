{
  "workerId": "docker-172-009",
  "taskId": "172-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T04:49:50.998Z",
  "exitCode": 0,
  "backend": "docker"
}