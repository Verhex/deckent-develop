{
  "workerId": "docker-173-020",
  "taskId": "173-020",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:34:00.347Z",
  "exitCode": 0,
  "backend": "docker"
}