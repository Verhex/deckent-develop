{
  "workerId": "docker-173-007",
  "taskId": "173-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:32:26.247Z",
  "exitCode": 0,
  "backend": "docker"
}