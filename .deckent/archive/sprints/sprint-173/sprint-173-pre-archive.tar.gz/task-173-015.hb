{
  "workerId": "docker-173-015",
  "taskId": "173-015",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:34:02.234Z",
  "exitCode": 0,
  "backend": "docker"
}