{
  "workerId": "docker-173-004",
  "taskId": "173-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:36:07.457Z",
  "exitCode": 0,
  "backend": "docker"
}