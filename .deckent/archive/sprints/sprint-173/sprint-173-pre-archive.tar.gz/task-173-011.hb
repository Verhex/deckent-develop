{
  "workerId": "docker-173-011",
  "taskId": "173-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:33:33.690Z",
  "exitCode": 0,
  "backend": "docker"
}