{
  "workerId": "docker-173-008",
  "taskId": "173-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:31:55.615Z",
  "exitCode": 0,
  "backend": "docker"
}