{
  "workerId": "docker-173-012",
  "taskId": "173-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:31:49.370Z",
  "exitCode": 0,
  "backend": "docker"
}