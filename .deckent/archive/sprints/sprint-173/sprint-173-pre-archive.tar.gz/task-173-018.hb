{
  "workerId": "docker-173-018",
  "taskId": "173-018",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:34:45.203Z",
  "exitCode": 0,
  "backend": "docker"
}