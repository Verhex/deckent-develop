{
  "workerId": "docker-173-003",
  "taskId": "173-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:30:45.173Z",
  "exitCode": 0,
  "backend": "docker"
}