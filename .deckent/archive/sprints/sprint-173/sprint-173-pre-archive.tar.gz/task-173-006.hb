{
  "workerId": "docker-173-006",
  "taskId": "173-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:31:35.856Z",
  "exitCode": 0,
  "backend": "docker"
}