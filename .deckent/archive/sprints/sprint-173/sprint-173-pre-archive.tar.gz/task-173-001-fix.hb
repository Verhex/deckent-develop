{
  "workerId": "docker-173-001-fix",
  "taskId": "173-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:44:33.839Z",
  "exitCode": 0,
  "backend": "docker"
}