{
  "workerId": "docker-173-009",
  "taskId": "173-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:33:05.945Z",
  "exitCode": 0,
  "backend": "docker"
}