{
  "workerId": "docker-173-013",
  "taskId": "173-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:32:46.154Z",
  "exitCode": 0,
  "backend": "docker"
}