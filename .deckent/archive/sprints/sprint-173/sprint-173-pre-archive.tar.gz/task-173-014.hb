{
  "workerId": "docker-173-014",
  "taskId": "173-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:33:00.369Z",
  "exitCode": 0,
  "backend": "docker"
}