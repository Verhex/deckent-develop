{
  "workerId": "docker-173-001",
  "taskId": "173-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:29:04.474Z",
  "exitCode": 0,
  "backend": "docker"
}