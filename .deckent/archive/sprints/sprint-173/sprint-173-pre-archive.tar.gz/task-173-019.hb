{
  "workerId": "docker-173-019",
  "taskId": "173-019",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:33:33.066Z",
  "exitCode": 0,
  "backend": "docker"
}