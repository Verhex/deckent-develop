{
  "workerId": "docker-173-021",
  "taskId": "173-021",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:39:38.658Z",
  "exitCode": 0,
  "backend": "docker"
}