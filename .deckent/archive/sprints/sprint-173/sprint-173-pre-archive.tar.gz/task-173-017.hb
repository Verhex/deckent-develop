{
  "workerId": "docker-173-017",
  "taskId": "173-017",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:32:30.153Z",
  "exitCode": 0,
  "backend": "docker"
}