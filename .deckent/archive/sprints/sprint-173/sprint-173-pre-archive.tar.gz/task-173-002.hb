{
  "workerId": "docker-173-002",
  "taskId": "173-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:29:47.249Z",
  "exitCode": 0,
  "backend": "docker"
}