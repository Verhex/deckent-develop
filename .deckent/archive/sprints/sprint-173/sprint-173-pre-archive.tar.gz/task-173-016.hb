{
  "workerId": "docker-173-016",
  "taskId": "173-016",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:32:29.985Z",
  "exitCode": 0,
  "backend": "docker"
}