{
  "workerId": "docker-173-010",
  "taskId": "173-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-18T19:33:10.519Z",
  "exitCode": 0,
  "backend": "docker"
}