{
  "workerId": "docker-195-004-fix",
  "taskId": "195-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:27:51.383Z",
  "exitCode": 0,
  "backend": "docker"
}