{
  "workerId": "docker-195-001",
  "taskId": "195-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:26:01.148Z",
  "exitCode": 0,
  "backend": "docker"
}