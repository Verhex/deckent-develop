{
  "workerId": "docker-195-002",
  "taskId": "195-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:18:32.018Z",
  "exitCode": 0,
  "backend": "docker"
}