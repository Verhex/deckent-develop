{
  "workerId": "docker-195-002-fix",
  "taskId": "195-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:29:10.136Z",
  "exitCode": 0,
  "backend": "docker"
}