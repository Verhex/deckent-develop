{
  "workerId": "docker-195-003",
  "taskId": "195-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:09:37.639Z",
  "exitCode": 0,
  "backend": "docker"
}