{
  "workerId": "docker-195-001-fix",
  "taskId": "195-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:34:52.365Z",
  "exitCode": 0,
  "backend": "docker"
}