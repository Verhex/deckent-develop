{
  "workerId": "docker-195-004",
  "taskId": "195-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:16:04.379Z",
  "exitCode": 0,
  "backend": "docker"
}