{
  "workerId": "docker-195-005",
  "taskId": "195-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-26T11:18:31.819Z",
  "exitCode": 0,
  "backend": "docker"
}