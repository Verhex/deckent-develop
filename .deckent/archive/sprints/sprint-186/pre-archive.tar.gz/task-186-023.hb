{
  "workerId": "docker-186-023",
  "taskId": "186-023",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:56:47.879Z",
  "exitCode": 0,
  "backend": "docker"
}