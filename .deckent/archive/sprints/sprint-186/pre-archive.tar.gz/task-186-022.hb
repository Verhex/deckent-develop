{
  "workerId": "docker-186-022",
  "taskId": "186-022",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:55:33.767Z",
  "exitCode": 0,
  "backend": "docker"
}