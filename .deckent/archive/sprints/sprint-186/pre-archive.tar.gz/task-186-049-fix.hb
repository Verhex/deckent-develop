{
  "workerId": "docker-186-049-fix",
  "taskId": "186-049-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:41.354Z",
  "exitCode": 0,
  "backend": "docker"
}