{
  "workerId": "docker-186-010",
  "taskId": "186-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:47:10.909Z",
  "exitCode": 0,
  "backend": "docker"
}