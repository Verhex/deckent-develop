{
  "workerId": "docker-186-037-fix",
  "taskId": "186-037-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:53.934Z",
  "exitCode": 0,
  "backend": "docker"
}