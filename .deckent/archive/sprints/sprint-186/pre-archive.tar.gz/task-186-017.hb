{
  "workerId": "docker-186-017",
  "taskId": "186-017",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:51:48.830Z",
  "exitCode": 0,
  "backend": "docker"
}