{
  "workerId": "docker-186-046-fix",
  "taskId": "186-046-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:40.758Z",
  "exitCode": 0,
  "backend": "docker"
}