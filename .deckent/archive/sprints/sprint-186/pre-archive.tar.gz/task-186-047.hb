{
  "workerId": "docker-186-047",
  "taskId": "186-047",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:04:11.561Z",
  "exitCode": 0,
  "backend": "docker"
}