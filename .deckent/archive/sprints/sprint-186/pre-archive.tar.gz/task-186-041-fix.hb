{
  "workerId": "docker-186-041-fix",
  "taskId": "186-041-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:14.350Z",
  "exitCode": 0,
  "backend": "docker"
}