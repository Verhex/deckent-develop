{
  "workerId": "docker-186-048-fix",
  "taskId": "186-048-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:41.155Z",
  "exitCode": 0,
  "backend": "docker"
}