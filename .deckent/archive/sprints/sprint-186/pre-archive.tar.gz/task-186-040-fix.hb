{
  "workerId": "docker-186-040-fix",
  "taskId": "186-040-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:14.165Z",
  "exitCode": 0,
  "backend": "docker"
}