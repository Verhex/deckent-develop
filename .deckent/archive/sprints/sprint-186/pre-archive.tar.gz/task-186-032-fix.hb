{
  "workerId": "docker-186-032-fix",
  "taskId": "186-032-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:52.948Z",
  "exitCode": 0,
  "backend": "docker"
}