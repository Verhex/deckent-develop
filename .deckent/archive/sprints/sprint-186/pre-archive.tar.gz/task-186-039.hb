{
  "workerId": "docker-186-039",
  "taskId": "186-039",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:37.431Z",
  "exitCode": 0,
  "backend": "docker"
}