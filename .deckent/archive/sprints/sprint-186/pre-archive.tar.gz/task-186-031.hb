{
  "workerId": "docker-186-031",
  "taskId": "186-031",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:07.413Z",
  "exitCode": 0,
  "backend": "docker"
}