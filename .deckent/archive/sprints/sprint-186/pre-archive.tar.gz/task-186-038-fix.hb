{
  "workerId": "docker-186-038-fix",
  "taskId": "186-038-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:13.799Z",
  "exitCode": 0,
  "backend": "docker"
}