{
  "workerId": "docker-186-025",
  "taskId": "186-025",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:59:33.864Z",
  "exitCode": 0,
  "backend": "docker"
}