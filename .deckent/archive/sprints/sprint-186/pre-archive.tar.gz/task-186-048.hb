{
  "workerId": "docker-186-048",
  "taskId": "186-048",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:04:11.764Z",
  "exitCode": 0,
  "backend": "docker"
}