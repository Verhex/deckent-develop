{
  "workerId": "docker-186-034",
  "taskId": "186-034",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:37.230Z",
  "exitCode": 0,
  "backend": "docker"
}