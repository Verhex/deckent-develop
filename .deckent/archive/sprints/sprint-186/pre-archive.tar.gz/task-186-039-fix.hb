{
  "workerId": "docker-186-039-fix",
  "taskId": "186-039-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:13.983Z",
  "exitCode": 0,
  "backend": "docker"
}