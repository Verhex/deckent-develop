{
  "workerId": "docker-186-011",
  "taskId": "186-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:46:37.213Z",
  "exitCode": 0,
  "backend": "docker"
}