{
  "workerId": "docker-186-006",
  "taskId": "186-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:43:40.695Z",
  "exitCode": 0,
  "backend": "docker"
}