{
  "workerId": "docker-186-008",
  "taskId": "186-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:46:51.267Z",
  "exitCode": 0,
  "backend": "docker"
}