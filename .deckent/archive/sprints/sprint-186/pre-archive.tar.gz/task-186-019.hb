{
  "workerId": "docker-186-019",
  "taskId": "186-019",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:56:02.020Z",
  "exitCode": 0,
  "backend": "docker"
}