{
  "workerId": "docker-186-035-fix",
  "taskId": "186-035-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:53.539Z",
  "exitCode": 0,
  "backend": "docker"
}