{
  "workerId": "docker-186-047-fix",
  "taskId": "186-047-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:40.960Z",
  "exitCode": 0,
  "backend": "docker"
}