{
  "workerId": "docker-186-049",
  "taskId": "186-049",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:04:11.968Z",
  "exitCode": 0,
  "backend": "docker"
}