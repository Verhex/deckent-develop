{
  "workerId": "docker-186-014",
  "taskId": "186-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:50:19.905Z",
  "exitCode": 0,
  "backend": "docker"
}