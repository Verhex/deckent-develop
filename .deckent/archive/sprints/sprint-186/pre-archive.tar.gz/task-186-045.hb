{
  "workerId": "docker-186-045",
  "taskId": "186-045",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:57.663Z",
  "exitCode": 0,
  "backend": "docker"
}