{
  "workerId": "docker-186-030",
  "taskId": "186-030",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:01:05.841Z",
  "exitCode": 0,
  "backend": "docker"
}