{
  "workerId": "docker-186-001",
  "taskId": "186-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:42:24.275Z",
  "exitCode": 0,
  "backend": "docker"
}