{
  "workerId": "docker-186-045-fix",
  "taskId": "186-045-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:40.574Z",
  "exitCode": 0,
  "backend": "docker"
}