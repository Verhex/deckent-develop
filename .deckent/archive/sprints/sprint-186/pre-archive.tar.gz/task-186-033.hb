{
  "workerId": "docker-186-033",
  "taskId": "186-033",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:26.738Z",
  "exitCode": 0,
  "backend": "docker"
}