{
  "workerId": "docker-186-020",
  "taskId": "186-020",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:56:01.498Z",
  "exitCode": 0,
  "backend": "docker"
}