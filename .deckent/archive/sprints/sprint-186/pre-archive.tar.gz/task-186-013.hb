{
  "workerId": "docker-186-013",
  "taskId": "186-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:48:25.482Z",
  "exitCode": 0,
  "backend": "docker"
}