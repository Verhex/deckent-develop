{
  "workerId": "docker-186-044-fix",
  "taskId": "186-044-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:40.395Z",
  "exitCode": 0,
  "backend": "docker"
}