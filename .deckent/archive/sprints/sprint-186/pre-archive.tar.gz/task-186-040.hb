{
  "workerId": "docker-186-040",
  "taskId": "186-040",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:37.631Z",
  "exitCode": 0,
  "backend": "docker"
}