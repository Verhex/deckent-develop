{
  "workerId": "docker-186-035",
  "taskId": "186-035",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:52.739Z",
  "exitCode": 0,
  "backend": "docker"
}