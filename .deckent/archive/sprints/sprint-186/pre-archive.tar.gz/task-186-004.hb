{
  "workerId": "docker-186-004",
  "taskId": "186-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:42:45.700Z",
  "exitCode": 0,
  "backend": "docker"
}