{
  "workerId": "docker-186-021",
  "taskId": "186-021",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:56:12.281Z",
  "exitCode": 0,
  "backend": "docker"
}