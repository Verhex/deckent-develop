{
  "workerId": "docker-186-015",
  "taskId": "186-015",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:51:48.987Z",
  "exitCode": 0,
  "backend": "docker"
}