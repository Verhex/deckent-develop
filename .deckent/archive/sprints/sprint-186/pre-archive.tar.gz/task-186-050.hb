{
  "workerId": "docker-186-050",
  "taskId": "186-050",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:04:12.158Z",
  "exitCode": 0,
  "backend": "docker"
}