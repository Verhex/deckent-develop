{
  "workerId": "docker-186-044",
  "taskId": "186-044",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:57.473Z",
  "exitCode": 0,
  "backend": "docker"
}