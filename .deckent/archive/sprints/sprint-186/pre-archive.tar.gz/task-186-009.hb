{
  "workerId": "docker-186-009",
  "taskId": "186-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:47:47.447Z",
  "exitCode": 0,
  "backend": "docker"
}