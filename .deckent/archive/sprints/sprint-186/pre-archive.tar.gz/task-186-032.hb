{
  "workerId": "docker-186-032",
  "taskId": "186-032",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:37.025Z",
  "exitCode": 0,
  "backend": "docker"
}