{
  "workerId": "docker-186-027",
  "taskId": "186-027",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:01:18.085Z",
  "exitCode": 0,
  "backend": "docker"
}