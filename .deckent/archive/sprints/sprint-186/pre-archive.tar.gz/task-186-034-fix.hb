{
  "workerId": "docker-186-034-fix",
  "taskId": "186-034-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:53.339Z",
  "exitCode": 0,
  "backend": "docker"
}