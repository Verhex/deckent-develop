{
  "workerId": "docker-186-050-fix",
  "taskId": "186-050-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:11:59.998Z",
  "exitCode": 0,
  "backend": "docker"
}