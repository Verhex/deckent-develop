{
  "workerId": "docker-186-003",
  "taskId": "186-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:41:49.313Z",
  "exitCode": 0,
  "backend": "docker"
}