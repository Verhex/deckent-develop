{
  "workerId": "docker-186-002",
  "taskId": "186-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:42:45.883Z",
  "exitCode": 0,
  "backend": "docker"
}