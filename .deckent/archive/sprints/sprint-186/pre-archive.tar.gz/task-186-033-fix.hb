{
  "workerId": "docker-186-033-fix",
  "taskId": "186-033-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:53.141Z",
  "exitCode": 0,
  "backend": "docker"
}