{
  "workerId": "docker-186-016",
  "taskId": "186-016",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:50:54.801Z",
  "exitCode": 0,
  "backend": "docker"
}