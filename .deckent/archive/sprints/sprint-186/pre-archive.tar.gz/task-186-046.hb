{
  "workerId": "docker-186-046",
  "taskId": "186-046",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:57.845Z",
  "exitCode": 0,
  "backend": "docker"
}