{
  "workerId": "docker-186-037",
  "taskId": "186-037",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:26.558Z",
  "exitCode": 0,
  "backend": "docker"
}