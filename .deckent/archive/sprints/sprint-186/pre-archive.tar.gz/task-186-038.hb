{
  "workerId": "docker-186-038",
  "taskId": "186-038",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:26.923Z",
  "exitCode": 0,
  "backend": "docker"
}