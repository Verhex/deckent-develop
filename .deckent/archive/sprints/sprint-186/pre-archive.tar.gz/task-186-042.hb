{
  "workerId": "docker-186-042",
  "taskId": "186-042",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:57.129Z",
  "exitCode": 0,
  "backend": "docker"
}