{
  "workerId": "docker-186-018",
  "taskId": "186-018",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:53:28.561Z",
  "exitCode": 0,
  "backend": "docker"
}