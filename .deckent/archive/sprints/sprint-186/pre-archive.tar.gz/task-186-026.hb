{
  "workerId": "docker-186-026",
  "taskId": "186-026",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:00:35.050Z",
  "exitCode": 0,
  "backend": "docker"
}