{
  "workerId": "docker-186-012",
  "taskId": "186-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:49:40.522Z",
  "exitCode": 0,
  "backend": "docker"
}