{
  "workerId": "docker-186-024",
  "taskId": "186-024",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:57:18.907Z",
  "exitCode": 0,
  "backend": "docker"
}