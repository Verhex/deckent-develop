{
  "workerId": "docker-186-036-fix",
  "taskId": "186-036-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:08:53.730Z",
  "exitCode": 0,
  "backend": "docker"
}