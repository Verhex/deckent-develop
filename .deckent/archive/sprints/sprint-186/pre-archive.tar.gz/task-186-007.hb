{
  "workerId": "docker-186-007",
  "taskId": "186-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T21:44:56.908Z",
  "exitCode": 0,
  "backend": "docker"
}