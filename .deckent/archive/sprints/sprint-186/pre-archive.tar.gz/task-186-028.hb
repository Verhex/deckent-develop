{
  "workerId": "docker-186-028",
  "taskId": "186-028",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:00:12.795Z",
  "exitCode": 0,
  "backend": "docker"
}