{
  "workerId": "docker-186-036",
  "taskId": "186-036",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:26.420Z",
  "exitCode": 0,
  "backend": "docker"
}