{
  "workerId": "docker-186-029",
  "taskId": "186-029",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:02:32.853Z",
  "exitCode": 0,
  "backend": "docker"
}