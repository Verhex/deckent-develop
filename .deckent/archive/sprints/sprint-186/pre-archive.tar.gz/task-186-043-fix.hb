{
  "workerId": "docker-186-043-fix",
  "taskId": "186-043-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:14.708Z",
  "exitCode": 0,
  "backend": "docker"
}