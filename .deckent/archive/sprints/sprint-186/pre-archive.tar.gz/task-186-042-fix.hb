{
  "workerId": "docker-186-042-fix",
  "taskId": "186-042-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:09:14.530Z",
  "exitCode": 0,
  "backend": "docker"
}