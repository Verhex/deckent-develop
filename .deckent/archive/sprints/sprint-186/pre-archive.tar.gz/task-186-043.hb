{
  "workerId": "docker-186-043",
  "taskId": "186-043",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-21T22:03:57.289Z",
  "exitCode": 0,
  "backend": "docker"
}