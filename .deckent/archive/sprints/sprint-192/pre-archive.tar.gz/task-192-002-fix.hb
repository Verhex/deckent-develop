{
  "workerId": "docker-192-002-fix",
  "taskId": "192-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:17:05.336Z",
  "exitCode": 0,
  "backend": "docker"
}