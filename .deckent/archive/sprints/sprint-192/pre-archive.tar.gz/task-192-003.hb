{
  "workerId": "docker-192-003",
  "taskId": "192-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T09:50:28.481Z",
  "exitCode": 0,
  "backend": "docker"
}