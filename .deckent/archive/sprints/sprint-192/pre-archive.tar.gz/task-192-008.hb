{
  "workerId": "docker-192-008",
  "taskId": "192-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:01:57.901Z",
  "exitCode": 0,
  "backend": "docker"
}