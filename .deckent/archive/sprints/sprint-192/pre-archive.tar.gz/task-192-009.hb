{
  "workerId": "docker-192-009",
  "taskId": "192-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:16:50.490Z",
  "exitCode": 0,
  "backend": "docker"
}