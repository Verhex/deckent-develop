{
  "workerId": "docker-192-001-fix",
  "taskId": "192-001-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:16:58.063Z",
  "exitCode": 0,
  "backend": "docker"
}