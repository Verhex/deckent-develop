{
  "workerId": "docker-192-010",
  "taskId": "192-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:14:19.648Z",
  "exitCode": 0,
  "backend": "docker"
}