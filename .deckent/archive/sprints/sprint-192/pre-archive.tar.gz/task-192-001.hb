{
  "workerId": "docker-192-001",
  "taskId": "192-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T09:47:33.537Z",
  "exitCode": 0,
  "backend": "docker"
}