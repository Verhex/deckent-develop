{
  "workerId": "docker-192-011-fix",
  "taskId": "192-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:33:04.983Z",
  "exitCode": 0,
  "backend": "docker"
}