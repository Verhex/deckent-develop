{
  "workerId": "docker-192-004-fix",
  "taskId": "192-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:16:57.895Z",
  "exitCode": 0,
  "backend": "docker"
}