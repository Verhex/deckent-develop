{
  "workerId": "docker-192-002",
  "taskId": "192-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T09:45:38.758Z",
  "exitCode": 0,
  "backend": "docker"
}