{
  "workerId": "docker-192-006-fix",
  "taskId": "192-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:17:05.527Z",
  "exitCode": 0,
  "backend": "docker"
}