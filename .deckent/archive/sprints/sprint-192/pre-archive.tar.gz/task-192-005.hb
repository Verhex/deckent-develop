{
  "workerId": "docker-192-005",
  "taskId": "192-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T09:55:51.547Z",
  "exitCode": 0,
  "backend": "docker"
}