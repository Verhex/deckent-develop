{
  "workerId": "docker-192-006",
  "taskId": "192-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T09:56:43.503Z",
  "exitCode": 0,
  "backend": "docker"
}