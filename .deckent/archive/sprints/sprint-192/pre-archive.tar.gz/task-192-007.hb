{
  "workerId": "docker-192-007",
  "taskId": "192-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:08:56.884Z",
  "exitCode": 0,
  "backend": "docker"
}