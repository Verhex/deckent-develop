{
  "workerId": "docker-192-004",
  "taskId": "192-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T09:52:48.105Z",
  "exitCode": 0,
  "backend": "docker"
}