{
  "workerId": "docker-192-011",
  "taskId": "192-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:16:50.661Z",
  "exitCode": 0,
  "backend": "docker"
}