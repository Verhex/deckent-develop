{
  "workerId": "docker-192-009-fix",
  "taskId": "192-009-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-24T10:21:59.522Z",
  "exitCode": 0,
  "backend": "docker"
}