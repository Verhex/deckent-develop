{
  "workerId": "docker-188-006",
  "taskId": "188-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:12:17.454Z",
  "exitCode": 0,
  "backend": "docker"
}