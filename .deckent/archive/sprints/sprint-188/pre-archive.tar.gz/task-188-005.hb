{
  "workerId": "docker-188-005",
  "taskId": "188-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:11:29.974Z",
  "exitCode": 0,
  "backend": "docker"
}