{
  "workerId": "docker-188-002",
  "taskId": "188-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:08:41.811Z",
  "exitCode": 0,
  "backend": "docker"
}