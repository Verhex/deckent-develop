{
  "workerId": "docker-188-012",
  "taskId": "188-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:29:21.327Z",
  "exitCode": 0,
  "backend": "docker"
}