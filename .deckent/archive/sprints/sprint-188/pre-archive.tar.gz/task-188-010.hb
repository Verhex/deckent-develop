{
  "workerId": "docker-188-010",
  "taskId": "188-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:20:29.406Z",
  "exitCode": 0,
  "backend": "docker"
}