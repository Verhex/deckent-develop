{
  "workerId": "docker-188-009",
  "taskId": "188-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:22:31.880Z",
  "exitCode": 0,
  "backend": "docker"
}