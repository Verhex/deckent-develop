{
  "workerId": "docker-188-004",
  "taskId": "188-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:13:25.484Z",
  "exitCode": 0,
  "backend": "docker"
}