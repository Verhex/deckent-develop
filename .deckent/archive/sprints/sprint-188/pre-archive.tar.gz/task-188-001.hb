{
  "workerId": "docker-188-001",
  "taskId": "188-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:10:07.037Z",
  "exitCode": 0,
  "backend": "docker"
}