{
  "workerId": "docker-188-008",
  "taskId": "188-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:17:37.571Z",
  "exitCode": 0,
  "backend": "docker"
}