{
  "workerId": "docker-188-011",
  "taskId": "188-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:31:24.994Z",
  "exitCode": 0,
  "backend": "docker"
}