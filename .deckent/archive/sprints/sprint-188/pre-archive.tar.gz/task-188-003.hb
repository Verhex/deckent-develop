{
  "workerId": "docker-188-003",
  "taskId": "188-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:13:17.928Z",
  "exitCode": 0,
  "backend": "docker"
}