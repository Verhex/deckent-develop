{
  "workerId": "docker-188-007",
  "taskId": "188-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-22T14:15:59.955Z",
  "exitCode": 0,
  "backend": "docker"
}