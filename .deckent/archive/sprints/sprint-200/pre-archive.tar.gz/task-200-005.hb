{
  "workerId": "docker-200-005",
  "taskId": "200-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:08:01.914Z",
  "exitCode": 0,
  "backend": "docker"
}