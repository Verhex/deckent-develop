{
  "workerId": "docker-200-007-fix",
  "taskId": "200-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:42:08.953Z",
  "exitCode": 0,
  "backend": "docker"
}