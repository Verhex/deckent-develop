{
  "workerId": "docker-200-004",
  "taskId": "200-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:13:43.751Z",
  "exitCode": 0,
  "backend": "docker"
}