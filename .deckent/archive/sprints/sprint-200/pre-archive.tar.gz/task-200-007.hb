{
  "workerId": "docker-200-007",
  "taskId": "200-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:09:59.437Z",
  "exitCode": 0,
  "backend": "docker"
}