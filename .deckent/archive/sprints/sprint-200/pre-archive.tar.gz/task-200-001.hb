{
  "workerId": "docker-200-001",
  "taskId": "200-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:13:03.977Z",
  "exitCode": 0,
  "backend": "docker"
}