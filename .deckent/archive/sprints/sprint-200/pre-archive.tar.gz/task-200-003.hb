{
  "workerId": "docker-200-003",
  "taskId": "200-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:15:28.088Z",
  "exitCode": 0,
  "backend": "docker"
}