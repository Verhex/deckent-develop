{
  "workerId": "docker-200-003-fix",
  "taskId": "200-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:35:48.108Z",
  "exitCode": 0,
  "backend": "docker"
}