{
  "workerId": "docker-200-006-fix",
  "taskId": "200-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:38:47.522Z",
  "exitCode": 0,
  "backend": "docker"
}