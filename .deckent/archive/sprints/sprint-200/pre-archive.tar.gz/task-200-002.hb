{
  "workerId": "docker-200-002",
  "taskId": "200-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:14:59.553Z",
  "exitCode": 0,
  "backend": "docker"
}