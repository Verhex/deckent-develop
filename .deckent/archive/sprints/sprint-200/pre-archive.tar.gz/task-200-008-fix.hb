{
  "workerId": "docker-200-008-fix",
  "taskId": "200-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:34:12.352Z",
  "exitCode": 0,
  "backend": "docker"
}