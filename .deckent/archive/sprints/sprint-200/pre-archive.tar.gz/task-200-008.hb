{
  "workerId": "docker-200-008",
  "taskId": "200-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:11:41.439Z",
  "exitCode": 0,
  "backend": "docker"
}