{
  "workerId": "docker-200-009",
  "taskId": "200-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:27:12.603Z",
  "exitCode": 0,
  "backend": "docker"
}