{
  "workerId": "docker-200-005-fix",
  "taskId": "200-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:38:31.216Z",
  "exitCode": 0,
  "backend": "docker"
}