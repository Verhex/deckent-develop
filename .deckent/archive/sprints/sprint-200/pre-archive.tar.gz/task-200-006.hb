{
  "workerId": "docker-200-006",
  "taskId": "200-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:32:42.460Z",
  "exitCode": 0,
  "backend": "docker"
}