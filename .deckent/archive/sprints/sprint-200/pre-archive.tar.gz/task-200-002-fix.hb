{
  "workerId": "docker-200-002-fix",
  "taskId": "200-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-31T02:37:43.476Z",
  "exitCode": 0,
  "backend": "docker"
}