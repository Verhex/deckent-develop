{
  "workerId": "docker-190-012",
  "taskId": "190-012",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:18:48.554Z",
  "exitCode": 0,
  "backend": "docker"
}