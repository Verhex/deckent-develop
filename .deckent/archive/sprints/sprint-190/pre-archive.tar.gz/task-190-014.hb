{
  "workerId": "docker-190-014",
  "taskId": "190-014",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:23:29.601Z",
  "exitCode": 0,
  "backend": "docker"
}