{
  "workerId": "docker-190-002",
  "taskId": "190-002",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:25:40.572Z",
  "exitCode": 0,
  "backend": "docker"
}