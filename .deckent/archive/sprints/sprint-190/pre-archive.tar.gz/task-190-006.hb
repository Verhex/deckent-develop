{
  "workerId": "docker-190-006",
  "taskId": "190-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:45:40.196Z",
  "exitCode": 0,
  "backend": "docker"
}