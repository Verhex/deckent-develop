{
  "workerId": "docker-190-011",
  "taskId": "190-011",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:41:28.241Z",
  "exitCode": 0,
  "backend": "docker"
}