{
  "workerId": "docker-190-016-fix",
  "taskId": "190-016-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:54:02.277Z",
  "exitCode": 0,
  "backend": "docker"
}