{
  "workerId": "docker-190-010-fix",
  "taskId": "190-010-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T20:02:13.076Z",
  "exitCode": 0,
  "backend": "docker"
}