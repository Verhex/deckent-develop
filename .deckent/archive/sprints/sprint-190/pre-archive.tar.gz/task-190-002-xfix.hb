{
  "workerId": "docker-190-002-xfix",
  "taskId": "190-002-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:54:38.099Z",
  "exitCode": 0,
  "backend": "docker"
}