{
  "workerId": "docker-190-007-fix",
  "taskId": "190-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T20:11:18.527Z",
  "exitCode": 0,
  "backend": "docker"
}