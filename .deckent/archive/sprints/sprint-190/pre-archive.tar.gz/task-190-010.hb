{
  "workerId": "docker-190-010",
  "taskId": "190-010",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:35:52.324Z",
  "exitCode": 0,
  "backend": "docker"
}