{
  "workerId": "docker-190-004",
  "taskId": "190-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:33:07.876Z",
  "exitCode": 0,
  "backend": "docker"
}