{
  "workerId": "docker-190-003",
  "taskId": "190-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:16:50.160Z",
  "exitCode": 0,
  "backend": "docker"
}