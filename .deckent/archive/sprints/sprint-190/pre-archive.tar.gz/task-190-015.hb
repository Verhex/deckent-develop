{
  "workerId": "docker-190-015",
  "taskId": "190-015",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-23T19:16:59.996Z",
  "exitCode": 137,
  "backend": "docker"
}