{
  "workerId": "docker-190-008",
  "taskId": "190-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:33:01.451Z",
  "exitCode": 0,
  "backend": "docker"
}