{
  "workerId": "docker-190-015-fix",
  "taskId": "190-015-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:58:09.551Z",
  "exitCode": 0,
  "backend": "docker"
}