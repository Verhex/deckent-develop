{
  "workerId": "docker-190-005",
  "taskId": "190-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:38:57.614Z",
  "exitCode": 0,
  "backend": "docker"
}