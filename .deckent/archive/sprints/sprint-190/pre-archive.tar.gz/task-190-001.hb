{
  "workerId": "docker-190-001",
  "taskId": "190-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:28:38.490Z",
  "exitCode": 0,
  "backend": "docker"
}