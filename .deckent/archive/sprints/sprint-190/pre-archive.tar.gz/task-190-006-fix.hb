{
  "workerId": "docker-190-006-fix",
  "taskId": "190-006-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T20:02:05.399Z",
  "exitCode": 0,
  "backend": "docker"
}