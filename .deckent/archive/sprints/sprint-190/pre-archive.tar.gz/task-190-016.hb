{
  "workerId": "docker-190-016",
  "taskId": "190-016",
  "status": "FAILED",
  "sequence": 99,
  "timestamp": "2026-05-23T19:17:17.963Z",
  "exitCode": 137,
  "backend": "docker"
}