{
  "workerId": "docker-190-009-xfix",
  "taskId": "190-009-xfix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:59:27.794Z",
  "exitCode": 0,
  "backend": "docker"
}