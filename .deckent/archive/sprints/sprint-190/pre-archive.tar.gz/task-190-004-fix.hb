{
  "workerId": "docker-190-004-fix",
  "taskId": "190-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:54:03.757Z",
  "exitCode": 0,
  "backend": "docker"
}