{
  "workerId": "docker-190-005-fix",
  "taskId": "190-005-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:58:04.074Z",
  "exitCode": 0,
  "backend": "docker"
}