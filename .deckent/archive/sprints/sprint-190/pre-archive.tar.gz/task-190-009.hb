{
  "workerId": "docker-190-009",
  "taskId": "190-009",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:29:15.884Z",
  "exitCode": 0,
  "backend": "docker"
}