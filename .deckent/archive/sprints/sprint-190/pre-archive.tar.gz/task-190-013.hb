{
  "workerId": "docker-190-013",
  "taskId": "190-013",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T19:25:30.713Z",
  "exitCode": 0,
  "backend": "docker"
}