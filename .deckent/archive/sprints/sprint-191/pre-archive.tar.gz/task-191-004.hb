{
  "workerId": "docker-191-004",
  "taskId": "191-004",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T22:53:32.826Z",
  "exitCode": 0,
  "backend": "docker"
}