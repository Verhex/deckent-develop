{
  "workerId": "docker-191-007",
  "taskId": "191-007",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:16:02.291Z",
  "exitCode": 0,
  "backend": "docker"
}