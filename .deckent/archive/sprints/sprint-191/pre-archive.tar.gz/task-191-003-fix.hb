{
  "workerId": "docker-191-003-fix",
  "taskId": "191-003-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:24:18.798Z",
  "exitCode": 0,
  "backend": "docker"
}