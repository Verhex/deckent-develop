{
  "workerId": "docker-191-008",
  "taskId": "191-008",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:19:09.715Z",
  "exitCode": 0,
  "backend": "docker"
}