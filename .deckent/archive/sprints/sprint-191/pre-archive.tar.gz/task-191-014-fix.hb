{
  "workerId": "docker-191-014-fix",
  "taskId": "191-014-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:47:47.105Z",
  "exitCode": 0,
  "backend": "docker"
}