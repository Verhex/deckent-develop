{
  "workerId": "docker-191-005",
  "taskId": "191-005",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:09:19.836Z",
  "exitCode": 0,
  "backend": "docker"
}