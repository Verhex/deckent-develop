{
  "workerId": "docker-191-007-fix",
  "taskId": "191-007-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:27:09.403Z",
  "exitCode": 0,
  "backend": "docker"
}