{
  "workerId": "docker-191-004-fix",
  "taskId": "191-004-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:22:08.826Z",
  "exitCode": 0,
  "backend": "docker"
}