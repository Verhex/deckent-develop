{
  "workerId": "docker-191-016-fix",
  "taskId": "191-016-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:48:47.249Z",
  "exitCode": 0,
  "backend": "docker"
}