{
  "workerId": "docker-191-003",
  "taskId": "191-003",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T22:56:27.324Z",
  "exitCode": 0,
  "backend": "docker"
}