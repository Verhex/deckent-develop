{
  "workerId": "docker-191-012-fix",
  "taskId": "191-012-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:42:34.696Z",
  "exitCode": 0,
  "backend": "docker"
}