{
  "workerId": "docker-191-009-fix",
  "taskId": "191-009-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:38:19.734Z",
  "exitCode": 0,
  "backend": "docker"
}