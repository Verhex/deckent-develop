{
  "workerId": "docker-191-011-fix",
  "taskId": "191-011-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:47:23.805Z",
  "exitCode": 0,
  "backend": "docker"
}