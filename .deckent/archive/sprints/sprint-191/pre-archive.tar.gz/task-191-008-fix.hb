{
  "workerId": "docker-191-008-fix",
  "taskId": "191-008-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:30:17.461Z",
  "exitCode": 0,
  "backend": "docker"
}