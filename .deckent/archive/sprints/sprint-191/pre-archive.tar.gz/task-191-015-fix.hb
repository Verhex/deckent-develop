{
  "workerId": "docker-191-015-fix",
  "taskId": "191-015-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:43:12.212Z",
  "exitCode": 0,
  "backend": "docker"
}