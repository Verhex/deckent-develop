{
  "workerId": "docker-191-001",
  "taskId": "191-001",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T22:56:14.720Z",
  "exitCode": 0,
  "backend": "docker"
}