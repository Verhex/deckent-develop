{
  "workerId": "docker-191-006",
  "taskId": "191-006",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:09:34.492Z",
  "exitCode": 0,
  "backend": "docker"
}