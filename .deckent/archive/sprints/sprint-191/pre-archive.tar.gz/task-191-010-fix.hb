{
  "workerId": "docker-191-010-fix",
  "taskId": "191-010-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:42:52.155Z",
  "exitCode": 0,
  "backend": "docker"
}