{
  "workerId": "docker-191-002-fix",
  "taskId": "191-002-fix",
  "status": "DONE",
  "sequence": 99,
  "timestamp": "2026-05-23T23:36:47.020Z",
  "exitCode": 0,
  "backend": "docker"
}